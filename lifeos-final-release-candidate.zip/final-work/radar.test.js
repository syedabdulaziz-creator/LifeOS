
function urgency(days){
  if(days==null || days>30) return "Later";
  if(days<0) return "Overdue";
  if(days===0) return "Today";
  if(days===1) return "Tomorrow";
  if(days<=7) return "This week";
  return "Upcoming";
}
const cases=[[-1,"Overdue"],[0,"Today"],[1,"Tomorrow"],[7,"This week"],[8,"Upcoming"],[30,"Upcoming"],[31,"Later"],[null,"Later"]];
for(const [d,e] of cases){if(urgency(d)!==e)throw new Error(`${d} => ${urgency(d)} expected ${e}`)}
console.log("Radar tests: PASS");
