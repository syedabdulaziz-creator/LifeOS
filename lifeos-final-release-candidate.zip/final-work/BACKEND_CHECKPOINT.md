
# LIFEOS Backend Checkpoint

## Current behavior
LIFEOS remains fully usable in local/offline mode when Supabase variables are empty.

## Cloud mode
Set:
- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_ANON_KEY`

Do NOT put a Supabase service-role key in the mobile app.

## Database
`supabase_schema.sql` contains the first production table and Row Level Security policies.

## Next backend work
1. Install `@supabase/supabase-js`
2. Add auth UI and session handling
3. Add cloud CRUD + offline queue
4. Add secure storage/session persistence
5. Add storage buckets for user documents with per-user policies
6. Test sign-in, sync, conflict handling and account deletion
