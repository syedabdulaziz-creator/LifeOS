# LIFEOS — Store Listing Draft

## App name
LIFEOS

## Subtitle / short description
You live. We remember.

## Short description
Remember receipts, deadlines, renewals, warranties and important documents in one private personal assistant.

## Full description
LIFEOS turns the scattered information in your digital life into things you can actually remember and act on.

Capture a receipt, screenshot, PDF, photo or piece of text. LIFEOS extracts useful details, saves them to your personal memory, watches important dates and brings the right things back to your attention.

### Remember what matters
- Purchases and receipts
- Return deadlines
- Subscriptions and renewals
- Warranties
- Bills and important dates
- Personal documents

### Stay ahead
LIFEOS Radar organizes upcoming deadlines and recurring charges so important dates don't disappear into your camera roll or email inbox.

### Ask your memory
Ask LIFEOS questions about the information you've saved and get answers from your personal LIFEOS memory.

### Work with documents
Use the built-in PDF toolkit for image-to-PDF, PDF merging, splitting and optimization, with document intelligence for supported imported content.

### Private by design
LIFEOS is built local-first. The release candidate does not require a paid AI API to provide its core intelligence, and the app contains no advertising.

### LIFEOS Pro
Pro is planned to unlock higher usage limits and premium capabilities through in-app subscriptions.

## Pricing
$7.99/month or $49.99/year (subject to final store configuration and regional pricing).

## Keywords
personal assistant, memory, receipts, reminders, warranty, subscriptions, documents, deadlines, PDF, organizer
