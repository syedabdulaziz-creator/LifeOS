
-- LIFEOS private document storage
-- Create a Storage bucket named `lifeos-documents` in Supabase.
-- These policies restrict objects to the authenticated user's folder:
-- lifeos-documents/<auth.uid()>/<filename>

insert into storage.buckets (id, name, public)
values ('lifeos-documents', 'lifeos-documents', false)
on conflict (id) do update set public = false;

drop policy if exists "LIFEOS users can read their own documents" on storage.objects;
create policy "LIFEOS users can read their own documents"
on storage.objects for select
to authenticated
using (
  bucket_id = 'lifeos-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "LIFEOS users can upload their own documents" on storage.objects;
create policy "LIFEOS users can upload their own documents"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'lifeos-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "LIFEOS users can update their own documents" on storage.objects;
create policy "LIFEOS users can update their own documents"
on storage.objects for update
to authenticated
using (
  bucket_id = 'lifeos-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'lifeos-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "LIFEOS users can delete their own documents" on storage.objects;
create policy "LIFEOS users can delete their own documents"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'lifeos-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);
