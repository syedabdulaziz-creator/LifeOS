
import React,{useState} from 'react';
import {View,Text,TextInput,Pressable,ScrollView} from 'react-native';
import {extractDocument,answerDocumentQuestion} from './documentIntelligence';

export default function DocumentAssistant({initialText=''}) {
 const[text,setText]=useState(initialText),[question,setQuestion]=useState(''),[result,setResult]=useState(null);
 return <ScrollView contentContainerStyle={{padding:18,gap:12}}>
  <Text style={{fontSize:26,fontWeight:'800'}}>AI Document Assistant</Text>
  <Text style={{color:'#6b7280'}}>LIFEOS analyzes documents locally first, extracting useful fields without requiring a paid AI API.</Text>
  <TextInput multiline value={text} onChangeText={setText} placeholder="Paste document or receipt text…" style={{minHeight:180,borderWidth:1,borderColor:'#d1d5db',borderRadius:14,padding:14,textAlignVertical:'top'}}/>
  <Pressable onPress={()=>setResult(extractDocument(text))} style={{backgroundColor:'#111827',padding:14,borderRadius:12}}><Text style={{color:'#fff',textAlign:'center',fontWeight:'800'}}>Analyze document</Text></Pressable>
  <TextInput value={question} onChangeText={setQuestion} placeholder="Ask: When is the return deadline?" style={{borderWidth:1,borderColor:'#d1d5db',borderRadius:12,padding:14}}/>
  <Pressable onPress={()=>setResult(answerDocumentQuestion(text,question))} style={{borderWidth:1,borderColor:'#111827',padding:14,borderRadius:12}}><Text style={{textAlign:'center',fontWeight:'800'}}>Ask this document</Text></Pressable>
  {result&&<View style={{padding:14,borderRadius:14,backgroundColor:'#f3f4f6',gap:6}}>
   <Text style={{fontWeight:'800'}}>{result.answer||(result.ok?'Document analyzed':'Analysis failed')}</Text>
   {result.fields&&Object.entries(result.fields).map(([k,v])=>v!=null&&k!=='rawText'?<Text key={k}>{k}: {String(v)}</Text>:null)}
   {result.error?<Text>{result.error}</Text>:null}
  </View>}
 </ScrollView>
}
