function cleanQuestion(question=''){return String(question).replace(/\s+/g,' ').trim().slice(0,500)}
function buildAIContext(items){return (items||[]).slice(0,100).map(item=>({id:item.id,title:item.title||null,merchant:item.merchant||null,type:item.type||null,amount:item.amount??null,currency:item.currency||'USD',deadline:item.deadline||null,deadlineLabel:item.deadlineLabel||null,renewalDate:item.renewalDate||null,warranty:item.warranty||null}))}
module.exports={cleanQuestion,buildAIContext}
