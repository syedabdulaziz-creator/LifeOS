import {Platform} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Purchases from 'react-native-purchases';

const ENTITLEMENT_KEY = 'lifeos_entitlement';
const REVENUECAT_PROVIDER = 'revenuecat';
const LOCAL_PROVIDER = 'local';
const PRO_ENTITLEMENT = 'lifeos_pro';

function configuredProvider() {
  const value = String(process.env.EXPO_PUBLIC_LIFEOS_BILLING_PROVIDER || LOCAL_PROVIDER).toLowerCase();
  return value === REVENUECAT_PROVIDER ? REVENUECAT_PROVIDER : LOCAL_PROVIDER;
}

function apiKeyForPlatform() {
  if (Platform.OS === 'ios') return String(process.env.EXPO_PUBLIC_REVENUECAT_IOS_KEY || '').trim();
  if (Platform.OS === 'android') return String(process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_KEY || '').trim();
  return '';
}

let configured = false;

async function initializeBilling() {
  if (configuredProvider() !== REVENUECAT_PROVIDER) return {configured: false, provider: LOCAL_PROVIDER};
  const apiKey = apiKeyForPlatform();
  if (!apiKey) return {configured: false, provider: REVENUECAT_PROVIDER, reason: 'missing_public_key'};
  if (!configured) {
    await Purchases.configure({apiKey});
    configured = true;
  }
  return {configured: true, provider: REVENUECAT_PROVIDER};
}

async function getEntitlement() {
  const localRaw = await AsyncStorage.getItem(ENTITLEMENT_KEY);
  if (configuredProvider() === REVENUECAT_PROVIDER) {
    try {
      const init = await initializeBilling();
      if (init.configured) {
        const info = await Purchases.getCustomerInfo();
        const isPro = Boolean(info?.entitlements?.active?.[PRO_ENTITLEMENT]);
        const value = {isPro, provider: REVENUECAT_PROVIDER, source: 'revenuecat'};
        await AsyncStorage.setItem(ENTITLEMENT_KEY, JSON.stringify(value));
        return value;
      }
    } catch (_) {}
  }
  if (!localRaw) return {isPro: false, provider: configuredProvider(), source: 'local'};
  try {
    const parsed = JSON.parse(localRaw);
    return {isPro: parsed.isPro === true, provider: parsed.provider || configuredProvider(), source: parsed.source || 'local'};
  } catch (_) {
    return {isPro: false, provider: configuredProvider(), source: 'local'};
  }
}

async function setLocalPreviewPro(enabled) {
  const value = {isPro: Boolean(enabled), provider: LOCAL_PROVIDER, source: 'preview'};
  await AsyncStorage.setItem(ENTITLEMENT_KEY, JSON.stringify(value));
  return value;
}

async function restorePurchases() {
  const init = await initializeBilling();
  if (!init.configured) return {ok: false, configured: false, message: 'Billing is not configured yet.'};
  try {
    const info = await Purchases.restorePurchases();
    const isPro = Boolean(info?.entitlements?.active?.[PRO_ENTITLEMENT]);
    await AsyncStorage.setItem(ENTITLEMENT_KEY, JSON.stringify({isPro, provider: REVENUECAT_PROVIDER, source: 'revenuecat'}));
    return {ok: true, configured: true, isPro};
  } catch (error) {
    return {ok: false, configured: true, message: error?.message || 'Could not restore purchases.'};
  }
}

async function purchasePro() {
  const init = await initializeBilling();
  if (!init.configured) return {ok: false, configured: false, message: 'LIFEOS Pro purchases are not configured yet.'};
  try {
    const offerings = await Purchases.getOfferings();
    const current = offerings?.current;
    const packages = current?.availablePackages || [];
    if (!packages.length) return {ok: false, configured: true, message: 'No LIFEOS Pro products are configured yet.'};
    const preferred = packages.find(p => /annual|year/i.test(p?.packageType || '') || /year/i.test(p?.product?.identifier || '')) || packages[0];
    const result = await Purchases.purchasePackage(preferred);
    const isPro = Boolean(result?.customerInfo?.entitlements?.active?.[PRO_ENTITLEMENT]);
    await AsyncStorage.setItem(ENTITLEMENT_KEY, JSON.stringify({isPro, provider: REVENUECAT_PROVIDER, source: 'revenuecat'}));
    return {ok: true, configured: true, isPro};
  } catch (error) {
    return {ok: false, configured: true, message: error?.message || 'Purchase was not completed.'};
  }
}

async function clearLocalEntitlement() {
  await AsyncStorage.removeItem(ENTITLEMENT_KEY);
}

export {ENTITLEMENT_KEY,REVENUECAT_PROVIDER,LOCAL_PROVIDER,PRO_ENTITLEMENT,configuredProvider,initializeBilling,getEntitlement,setLocalPreviewPro,restorePurchases,purchasePro,clearLocalEntitlement};
