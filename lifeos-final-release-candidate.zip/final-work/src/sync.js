
import { supabase, cloudEnabled } from './supabaseClient';
import { getStoredItems, saveStoredItems } from './backend';

function toRow(item, userId) {
  return {
    id: item.id,
    user_id: userId,
    title: item.title || 'Untitled',
    merchant: item.merchant || null,
    item_type: item.type || item.item_type || null,
    amount: Number.isFinite(Number(item.amount)) ? Number(item.amount) : null,
    currency: item.currency || 'USD',
    purchase_date: item.purchaseDate || null,
    deadline: item.deadline || null,
    deadline_label: item.deadlineLabel || null,
    renewal_date: item.renewalDate || null,
    warranty: item.warranty || null,
    source: item.source || null,
    source_name: item.sourceName || null,
    metadata: item.metadata || {},
    updated_at: item.updatedAt || new Date().toISOString(),
  };
}

function fromRow(row) {
  return {
    id: row.id,
    title: row.title,
    merchant: row.merchant,
    type: row.item_type,
    amount: row.amount,
    currency: row.currency,
    purchaseDate: row.purchase_date,
    deadline: row.deadline,
    deadlineLabel: row.deadline_label,
    renewalDate: row.renewal_date,
    warranty: row.warranty,
    source: row.source,
    sourceName: row.source_name,
    metadata: row.metadata || {},
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function syncItems(userId) {
  const local = await getStoredItems();

  if (!cloudEnabled || !supabase || !userId) {
    return { items: local, mode: 'local', uploaded: 0, downloaded: 0 };
  }

  // First push local items. Upsert is idempotent and safe for retries.
  const rows = local.map(item => toRow(item, userId));
  if (rows.length) {
    const { error } = await supabase
      .from('lifeos_items')
      .upsert(rows, { onConflict: 'id' });
    if (error) throw error;
  }

  const { data, error } = await supabase
    .from('lifeos_items')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;

  const cloudItems = (data || []).map(fromRow);
  // Server rows are authoritative after a successful push. The timestamp
  // field is retained so future conflict resolution can compare versions.
  await saveStoredItems(cloudItems);

  return {
    items: cloudItems,
    mode: 'supabase',
    uploaded: rows.length,
    downloaded: cloudItems.length,
  };
}
