import {getStoredItems} from './backend';
import {scheduleLifeOSNotifications} from './notificationService';

export async function refreshLifeOSMonitoring(requestPermission=false,itemsOverride=null){
  const items=Array.isArray(itemsOverride)?itemsOverride:await getStoredItems();
  return scheduleLifeOSNotifications(items,{requestPermission});
}
