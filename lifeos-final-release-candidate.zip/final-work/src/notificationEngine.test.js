
const fs=require('fs'),vm=require('vm');
function load(path){let s=fs.readFileSync(path,'utf8').replace(/export function /g,'function ').replace(/export \{[^}]+\};?/g,'');s+='\nmodule.exports={buildNotificationPlan,notificationCandidates,notificationDate,shouldNotify};';const c={module:{exports:{}},exports:{}};vm.runInNewContext(s,c);return c.module.exports}
const n=load('src/notificationEngine.js');function a(x,m){if(!x)throw new Error(m)}
// Fixed-date candidates.
const old=Date;
global.Date=class extends old { constructor(...args){ if(args.length===0) super('2026-09-27T12:00:00Z'); else super(...args);} static now(){return new old('2026-09-27T12:00:00Z').getTime();}};
const items=[
 {id:'1',title:'AirPods',deadline:'2026-10-04',deadlineLabel:'Return deadline'},
 {id:'2',title:'Netflix',type:'subscription',renewalDate:'2026-09-28'},
 {id:'3',title:'Laptop',warranty:'2026-09-28'},
 {id:'4',title:'Far future',deadline:'2026-11-30'}
];
const plan=n.buildNotificationPlan(items);
a(plan.length===3,'plan count');
a(plan.some(x=>x.kind==='deadline'),'deadline plan');
a(plan.some(x=>x.kind==='renewal'),'renewal plan');
a(plan.some(x=>x.kind==='warranty'),'warranty plan');
a(!plan.some(x=>x.itemId==='4'),'far future excluded');
a(n.notificationDate('2026-10-04',1)==='2026-10-03','date calculation');
a(n.notificationDate('Oct 4, 2026',1)==='2026-10-03','human date calculation');
console.log('notification planning tests: PASS');
