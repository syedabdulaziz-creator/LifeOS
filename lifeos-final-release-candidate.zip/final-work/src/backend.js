
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

export const backendConfig = {
  mode: SUPABASE_URL && SUPABASE_ANON_KEY ? 'supabase' : 'local',
  configured: Boolean(SUPABASE_URL && SUPABASE_ANON_KEY),
};

const KEYS = {
  session: '@lifeos/session',
  items: 'lifeos_items',
};

export async function getStoredItems() {
  const raw = await AsyncStorage.getItem(KEYS.items);
  if (!raw) return [];
  try { return JSON.parse(raw); } catch { return []; }
}

export async function saveStoredItems(items) {
  await AsyncStorage.setItem(KEYS.items, JSON.stringify(items || []));
  return items || [];
}

export async function getLocalSession() {
  const raw = await AsyncStorage.getItem(KEYS.session);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

export async function setLocalSession(session) {
  if (!session) {
    await AsyncStorage.removeItem(KEYS.session);
    return null;
  }
  await AsyncStorage.setItem(KEYS.session, JSON.stringify(session));
  return session;
}

/*
 * Supabase connection is intentionally not initialized until credentials exist.
 * This prevents accidental crashes and prevents secrets from being committed.
 * Production authentication/sync will use the public anon key only; service-role
 * credentials must never ship inside the mobile app.
 */
export function getBackendStatus() {
  return {
    mode: backendConfig.mode,
    configured: backendConfig.configured,
    requiresConfiguration: !backendConfig.configured,
  };
}
