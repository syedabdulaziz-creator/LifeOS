const fs=require('fs');
const s=fs.readFileSync('src/pdfEngine.js','utf8');
for(const token of ['PDFDocument','mergePdfs','splitPdf','compressPdf','writeAsStringAsync','useObjectStreams']) if(!s.includes(token)) throw Error(`missing ${token}`);
if(!/output\.copyPages\(source,source\.getPageIndices\(\)\)/.test(s)) throw Error('merge page copy missing');
if(!/requested\.map\(n=>n-1\)/.test(s)) throw Error('split page indexing missing');
console.log('PDF engine integration checks: PASS');
