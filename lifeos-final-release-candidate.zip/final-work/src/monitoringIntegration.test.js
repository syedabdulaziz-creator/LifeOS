const fs=require('fs');
const backend=fs.readFileSync('src/backend.js','utf8');
const coordinator=fs.readFileSync('src/monitoringCoordinator.js','utf8');
const app=fs.readFileSync('App.js','utf8');
if(!backend.includes("items: 'lifeos_items'")) throw Error('storage key mismatch');
if(!coordinator.includes('itemsOverride=null')) throw Error('monitoring override missing');
if(!coordinator.includes('Array.isArray(itemsOverride)?itemsOverride:await getStoredItems()')) throw Error('override not used');
if(!app.includes('refreshLifeOSMonitoring(false,next)')) throw Error('new items not passed to monitoring');
console.log('monitoring integration regression: PASS');
