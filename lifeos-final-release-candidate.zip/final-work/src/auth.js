
import { supabase, cloudEnabled } from './supabaseClient';
import { getLocalSession, setLocalSession } from './backend';

export async function getSession() {
  if (!cloudEnabled || !supabase) return getLocalSession();
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session || null;
}

export async function signUp(email, password) {
  if (!cloudEnabled || !supabase) {
    const session = { user: { id: `local-${Date.now()}`, email }, local: true };
    await setLocalSession(session);
    return { session, user: session.user };
  }
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) throw error;
  return { session: data.session, user: data.user };
}

export async function signIn(email, password) {
  if (!cloudEnabled || !supabase) {
    const session = { user: { id: `local-${Date.now()}`, email }, local: true };
    await setLocalSession(session);
    return { session, user: session.user };
  }
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return { session: data.session, user: data.user };
}

export async function signOut() {
  if (!cloudEnabled || !supabase) {
    await setLocalSession(null);
    return;
  }
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}


export async function requestPasswordReset(email) {
  if (!email?.trim()) throw new Error('Enter your email first.');
  if (!cloudEnabled || !supabase) {
    return { local: true };
  }
  const redirectTo = process.env.EXPO_PUBLIC_AUTH_REDIRECT_URL || undefined;
  const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), redirectTo ? { redirectTo } : undefined);
  if (error) throw error;
  return { local: false };
}

/*
 * Client-side account deletion can only safely remove user-owned rows.
 * Supabase auth.users deletion must be performed by a trusted server/Edge
 * Function, never with a service-role key embedded in the mobile app.
 */
export async function deleteMyCloudData(userId) {
  if (!cloudEnabled || !supabase || !userId) return { local: true };
  const { error } = await supabase
    .from('lifeos_items')
    .delete()
    .eq('user_id', userId);
  if (error) throw error;
  return { local: false };
}
