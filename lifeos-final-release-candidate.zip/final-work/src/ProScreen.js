import React, {useEffect, useState} from 'react';
import {ActivityIndicator, Pressable, ScrollView, Text, View} from 'react-native';
import {getEntitlement,purchasePro,restorePurchases,setLocalPreviewPro} from './billing';
import {FREE_LIMITS,PRO_FEATURES} from './entitlements';

export default function ProScreen({close}) {
  const [entitlement,setEntitlement]=useState({isPro:false});
  const [busy,setBusy]=useState(false);
  const [status,setStatus]=useState('');

  useEffect(()=>{getEntitlement().then(setEntitlement).catch(()=>{});},[]);

  async function buy() {
    setBusy(true); setStatus('');
    try {
      const result=await purchasePro();
      setStatus(result.message);
    } catch(e) { setStatus(e?.message||'Could not start checkout.'); }
    finally { setBusy(false); }
  }

  async function restore() {
    setBusy(true); setStatus('');
    try {
      const result=await restorePurchases();
      setStatus(result.message);
      if(result.entitlement) setEntitlement(result.entitlement);
    } catch(e) { setStatus(e?.message||'Could not restore purchases.'); }
    finally { setBusy(false); }
  }

  async function preview() {
    const next=await setLocalPreviewPro(true);
    setEntitlement(next);
    setStatus('Pro preview enabled on this device only. This is not a real purchase.');
  }

  return <View style={{flex:1,backgroundColor:'#F9FAFB',justifyContent:'flex-end'}}>
    <ScrollView contentContainerStyle={{backgroundColor:'#F9FAFB',padding:22,paddingBottom:35,borderTopLeftRadius:28,borderTopRightRadius:28}}>
      <View style={{width:42,height:4,borderRadius:3,backgroundColor:'#D1D5DB',alignSelf:'center',marginBottom:22}}/>
      <Text style={{fontSize:30,fontWeight:'900',color:'#111827'}}>LIFEOS Pro</Text>
      <Text style={{fontSize:15,color:'#667085',lineHeight:22,marginTop:7}}>Your personal memory layer, without limits.</Text>
      <View style={{backgroundColor:'#111827',borderRadius:22,padding:20,marginTop:22}}>
        <Text style={{color:'#fff',fontSize:16,fontWeight:'800'}}>Pro</Text>
        <Text style={{color:'#fff',fontSize:34,fontWeight:'900',marginTop:5}}>$7.99<Text style={{fontSize:14,fontWeight:'600'}}>/month</Text></Text>
        <Text style={{color:'#C7CBD3',fontSize:12,marginTop:2}}>$49.99/year · no ads</Text>
      </View>
      <Text style={{fontSize:11,fontWeight:'900',letterSpacing:1.3,color:'#8A929F',marginTop:25,marginBottom:8}}>INCLUDED</Text>
      {PRO_FEATURES.map(feature=><View key={feature} style={{paddingVertical:10,flexDirection:'row',gap:10}}><Text style={{fontSize:16}}>✓</Text><Text style={{fontSize:14,color:'#20252D',fontWeight:'700'}}>{feature}</Text></View>)}
      <Text style={{fontSize:12,color:'#7A8290',lineHeight:18,marginTop:12}}>Free includes {FREE_LIMITS.savedItems} saved items, {FREE_LIMITS.aiAnalysesPerMonth} AI document analyses/month and {FREE_LIMITS.pdfOperationsPerMonth} PDF operations/month.</Text>
      {entitlement.isPro && <Text style={{marginTop:14,fontWeight:'800',color:'#2D6A4F'}}>Pro is active on this device.</Text>}
      {!!status && <Text style={{marginTop:14,color:'#667085',lineHeight:19}}>{status}</Text>}
      <Pressable disabled={busy||entitlement.isPro} onPress={buy} style={{marginTop:18,height:54,borderRadius:17,backgroundColor:'#111827',alignItems:'center',justifyContent:'center'}}>{busy?<ActivityIndicator color="#fff"/>:<Text style={{color:'#fff',fontWeight:'800'}}>Start Pro</Text>}</Pressable>
      <Pressable disabled={busy} onPress={restore} style={{padding:15,alignItems:'center'}}><Text style={{fontWeight:'800',color:'#111827'}}>Restore purchases</Text></Pressable>
      <Pressable onPress={preview} style={{padding:10,alignItems:'center'}}><Text style={{fontSize:11,color:'#98A2B3'}}>Developer preview: enable Pro locally</Text></Pressable>
      <Pressable onPress={close} style={{padding:15,alignItems:'center'}}><Text style={{color:'#667085'}}>Done</Text></Pressable>
    </ScrollView>
  </View>;
}
