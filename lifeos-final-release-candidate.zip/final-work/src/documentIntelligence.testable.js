
const MONEY_RE = /(?:[$€£]\s?|\b(?:USD|EUR|GBP)\s?)(\d{1,5}(?:[,\s]\d{3})*(?:\.\d{2})?)/i;
const DATE_RE = /\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:,\s*|\s+)\d{4}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\b/i;
const MONTHS = {jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11};

function normalize(text=''){return text.replace(/\r/g,'').replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n').trim();}
function lines(text){return normalize(text).split('\n').map(x=>x.trim()).filter(Boolean);}
function parseMoney(text){const m=text.match(MONEY_RE);if(!m)return null;const n=Number(m[1].replace(/[,\s]/g,''));return Number.isFinite(n)?n:null;}
function parseDate(raw){
 if(!raw)return null; const s=raw.trim();
 const named=s.match(/^([A-Za-z]+)\.?[\s]+(\d{1,2})(?:,\s*|\s+)(\d{4})$/);
 if(named){const mon=MONTHS[named[1].slice(0,3).toLowerCase()];if(mon===undefined)return null;const d=new Date(Number(named[3]),mon,Number(named[2]));return isNaN(d.getTime())?null:d.toISOString().slice(0,10);}
 const parts=s.split(/[/-]/); if(parts.length===3){let[a,b,c]=parts.map(Number);if(c<100)c+=2000;const month=a>12?b:a;const day=a>12?a:b;const d=new Date(c,month-1,day);return isNaN(d.getTime())?null:d.toISOString().slice(0,10);}
 return null;
}
function findDate(text,keywords){for(const line of lines(text)){if(keywords.some(k=>line.toLowerCase().includes(k))){const m=line.match(DATE_RE);if(m)return parseDate(m[1]);}}return null;}
function findMerchant(text){const ls=lines(text),skip=/^(receipt|invoice|order|total|subtotal|tax|date|thank|payment|visa|mastercard|cash|change|qty|quantity|price)$/i;for(const line of ls.slice(0,8)){if(line.length>=3&&line.length<=60&&!skip.test(line)&&!(/^\W*\d/.test(line)))return line;}return null;}
function findTitle(text){const ls=lines(text),bad=/^(receipt|invoice|order|total|subtotal|tax|date|thank|payment|visa|mastercard|cash|change|qty|quantity|price|amount)$/i;for(const line of ls){if(line.length>=3&&line.length<=80&&!bad.test(line)&&!/\b(?:address|phone|www\.|http)\b/i.test(line)&&!MONEY_RE.test(line))return line;}return'Untitled document';}
function classify(text){const t=text.toLowerCase();if(/\b(warranty|limited warranty|coverage)\b/.test(t))return'warranty';if(/\b(subscription|monthly plan|annual plan|renews?|renewal|recurring)\b/.test(t))return'subscription';if(/\b(receipt|order total|subtotal|tax|purchase|sold to)\b/.test(t))return'receipt';if(/\b(invoice|amount due|balance due|due date)\b/.test(t))return'bill';return'document';}
function confidence(fields){let score=0;if(fields.merchant)score+=.2;if(fields.title&&fields.title!=='Untitled document')score+=.15;if(fields.amount!=null)score+=.2;if(fields.purchaseDate)score+=.15;if(fields.deadline)score+=.2;if(fields.renewalDate)score+=.1;return Math.min(1,Number(score.toFixed(2)));}
function extractDocument(text=''){
 const normalized=normalize(text);if(!normalized)return{ok:false,error:'No document text was provided.'};
 const type=classify(normalized),deadline=findDate(normalized,['return by','return before','returns until','due date','payment due','expires','expiration','exp date'])||findDate(normalized,['renewal date','renews on']),renewalDate=findDate(normalized,['renewal date','renews on','next billing','next payment']),purchaseDate=findDate(normalized,['purchase date','purchased','order date','transaction date','date of purchase','date']),warranty=findDate(normalized,['warranty until','warranty expires','coverage until'])||(/\bwarranty\b/i.test(normalized)?'Detected in document':null);
 const fields={title:findTitle(normalized),merchant:findMerchant(normalized),amount:parseMoney(normalized),type,purchaseDate,deadline,deadlineLabel:deadline?(/\b(return|returns)\b/i.test(normalized)?'Return deadline':/\b(due|payment)\b/i.test(normalized)?'Payment due':'Document deadline'):null,renewalDate,warranty,source:'document',confidence:0,extractedAt:new Date().toISOString()};
 fields.confidence=confidence(fields);return{ok:true,fields,rawText:normalized};
}
function answerDocumentQuestion(documentText,question){
 const result=extractDocument(documentText);if(!result.ok)return result;const q=(question||'').toLowerCase(),f=result.fields;
 if(/\b(merchant|seller|store)\b/.test(q))return{answer:f.merchant||'I could not identify the merchant.',fields:f};
 if(/\b(amount|price|cost|paid|pay|total|spend|spent)\b/.test(q))return{answer:f.amount!=null?`$${f.amount.toFixed(2)}`:'I could not identify an amount.',fields:f};
 if(/\b(return|deadline|due|expire)\b/.test(q))return{answer:f.deadline||'I could not identify a deadline.',fields:f};
 if(/\b(renew|subscription|billing)\b/.test(q))return{answer:f.renewalDate||'I could not identify a renewal date.',fields:f};
 if(/\b(warranty|coverage)\b/.test(q))return{answer:f.warranty||'I could not identify warranty information.',fields:f};
 return{answer:`I identified this as a ${f.type}. Key item: ${f.title}.`,fields:f};
}
module.exports={extractDocument,answerDocumentQuestion};
