
const fs=require('fs'),vm=require('vm');
function load(path){let s=fs.readFileSync(path,'utf8').replace(/export function /g,'function ').replace(/export \{[^}]+\};?/g,'');s+='\nmodule.exports={normalizeExtractedItem,buildMonitoring,buildRadar,ingestDocument,daysUntil,urgency};';const c={module:{exports:{}},exports:{}};vm.runInNewContext(s,c);return c.module.exports}
const d=load('src/lifeosDomain.js');function a(x,m){if(!x)throw new Error(m)}
const fake=t=>({ok:true,fields:{title:'AirPods Pro 2',merchant:'Amazon',type:'receipt',amount:249.99,purchaseDate:'2026-09-20',deadline:'2026-10-04',deadlineLabel:'Return deadline',confidence:.9}});
let r=d.ingestDocument('receipt',fake);a(r.ok,'ingest');a(r.item.monitoring,'new item monitoring');a(r.events[0].daysUntil===7,'deadline days');
const sub={id:'s1',title:'Netflix',type:'subscription',amount:22.99,renewalDate:'2026-10-15'};
const old={id:'o1',title:'Old Return',type:'receipt',deadline:'2026-09-25',amount:100};
const soon={id:'s2',title:'Return Soon',type:'receipt',deadline:'2026-09-28',amount:250};
let radar=d.buildRadar([sub,old,soon],'2026-09-27');
a(radar.today.length===1,'today count');a(radar.today[0].title==='Old Return','overdue priority');a(radar.money.some(x=>x.title==='Netflix'),'money radar');a(radar.monitored.length===3,'monitoring derived');a(radar.monitored.find(x=>x.title==='Netflix').monitoringEvents[0].kind==='renewal','renewal event');a(radar.deadlines[0].title==='Old Return','deadline priority');
a(d.urgency('2026-09-26','2026-09-27')==='overdue','overdue');a(d.urgency('2026-09-27','2026-09-27')==='today','today');a(d.urgency('2026-09-28','2026-09-27')==='tomorrow','tomorrow');a(d.urgency('2026-10-04','2026-09-27')==='this-week','week');a(d.urgency('2026-10-27','2026-09-27')==='next-30-days','30 days');a(d.urgency('2026-11-01','2026-09-27')==='later','later');
console.log('core loop integration tests: PASS');
