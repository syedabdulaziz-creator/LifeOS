const FREE_LIMITS = Object.freeze({
  savedItems: 50,
  aiAnalysesPerMonth: 10,
  pdfOperationsPerMonth: 5,
});

const PRO_FEATURES = Object.freeze([
  'Unlimited LIFEOS memory',
  'Unlimited AI document analysis',
  'Unlimited PDF tools',
  'Smart monitoring and alerts',
  'No ads',
]);

function monthKey(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function defaultUsage() {
  return { month: monthKey(), aiAnalyses: 0, pdfOperations: 0 };
}

function normalizeUsage(usage) {
  const current = monthKey();
  if (!usage || usage.month !== current) return defaultUsage();
  return {
    month: current,
    aiAnalyses: Math.max(0, Number(usage.aiAnalyses || 0)),
    pdfOperations: Math.max(0, Number(usage.pdfOperations || 0)),
  };
}

function isPro(entitlement) {
  return entitlement?.isPro === true;
}

function canUse(entitlement, usage, resource, currentCount = 0) {
  if (isPro(entitlement)) return true;
  const normalized = normalizeUsage(usage);
  if (resource === 'savedItems') return currentCount < FREE_LIMITS.savedItems;
  if (resource === 'aiAnalyses') return normalized.aiAnalyses < FREE_LIMITS.aiAnalysesPerMonth;
  if (resource === 'pdfOperations') return normalized.pdfOperations < FREE_LIMITS.pdfOperationsPerMonth;
  return false;
}

function recordUsage(usage, resource) {
  const next = normalizeUsage(usage);
  if (resource === 'aiAnalyses') next.aiAnalyses += 1;
  if (resource === 'pdfOperations') next.pdfOperations += 1;
  return next;
}

function remaining(usage, resource) {
  const normalized = normalizeUsage(usage);
  if (resource === 'aiAnalyses') return Math.max(0, FREE_LIMITS.aiAnalysesPerMonth - normalized.aiAnalyses);
  if (resource === 'pdfOperations') return Math.max(0, FREE_LIMITS.pdfOperationsPerMonth - normalized.pdfOperations);
  return null;
}

export {FREE_LIMITS, PRO_FEATURES, monthKey, defaultUsage, normalizeUsage, isPro, canUse, recordUsage, remaining};
