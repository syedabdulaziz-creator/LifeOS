const {cleanQuestion,buildAIContext}=require('./lifeosAI.testable.js');
const {answerPersonalMemory,daysUntil}=require('./memoryEngine.testable.js');
function assert(x,msg){if(!x)throw new Error(msg)}
assert(cleanQuestion('  what   is   my   warranty?  ')==='what is my warranty?','question cleaning');
const items=[
 {id:'1',title:'AirPods Pro',type:'Purchase',merchant:'Amazon',amount:249,deadline:'2026-10-17',warranty:'2027-09-17'},
 {id:'2',title:'Adobe Creative Cloud',type:'Subscription',merchant:'Adobe',amount:59.99,deadline:'2026-10-01'},
 {id:'3',title:'Auto insurance',type:'Renewal',merchant:'GEICO',amount:128,deadline:'2026-10-08'}
];
let r=answerPersonalMemory(items,'What subscriptions am I paying for?');assert(r.body.includes('$59.99'),'subscription answer');
r=answerPersonalMemory(items,'What warranties do I have?');assert(r.body.includes('AirPods Pro'),'warranty answer');
r=answerPersonalMemory(items,'What purchases did I save?');assert(r.body.includes('Amazon'),'purchase answer');
assert(daysUntil('2026-10-17')>0,'date calculation');
const ctx=buildAIContext(items);assert(ctx.length===3 && ctx[0].id==='1','AI context');assert(!('rawText' in ctx[0]),'raw text must not enter personal AI context');
console.log('lifeos AI tests: PASS');
