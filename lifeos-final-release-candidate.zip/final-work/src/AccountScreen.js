
import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ActivityIndicator } from 'react-native';
import { signIn, signUp, signOut, getSession, requestPasswordReset, deleteMyCloudData } from './auth';
import { backendMode } from './supabaseClient';
import { syncItems } from './sync';

export default function AccountScreen({ onDone }) {
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('signin');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { getSession().then(setSession).catch(e => setStatus(e.message)); }, []);

  async function submit() {
    if (!email.trim() || password.length < 6) {
      setStatus('Enter an email and a password with at least 6 characters.');
      return;
    }
    try {
      setBusy(true); setStatus('');
      const result = mode === 'signin'
        ? await signIn(email.trim(), password)
        : await signUp(email.trim(), password);
      setSession(result.session || { user: result.user });
      if (result.session?.user?.id) await syncItems(result.session.user.id);
      setStatus(backendMode() === 'local'
        ? 'Local account active. Cloud sync will activate when Supabase is configured.'
        : 'Account connected and LIFEOS memory synced.');
    } catch (e) {
      setStatus(e?.message || 'Authentication failed.');
    } finally { setBusy(false); }
  }

  async function resetPassword() {
    try {
      setBusy(true); setStatus('');
      await requestPasswordReset(email);
      setStatus(backendMode() === 'local'
        ? 'Password reset is available after cloud mode is enabled.'
        : 'If that email exists, a password reset message has been sent.');
    } catch(e) { setStatus(e?.message || 'Password reset failed.'); }
    finally { setBusy(false); }
  }

  async function deleteAccountData() {
    try {
      setBusy(true); setStatus('');
      if (session?.user?.id) await deleteMyCloudData(session.user.id);
      await signOut();
      setSession(null);
      setStatus('Your LIFEOS cloud data was deleted and you were signed out.');
    } catch(e) { setStatus(e?.message || 'Account deletion failed.'); }
    finally { setBusy(false); }
  }

  async function logout() {
    try { setBusy(true); await signOut(); setSession(null); setStatus('Signed out.'); }
    catch(e){ setStatus(e?.message || 'Sign out failed.'); }
    finally { setBusy(false); }
  }

  return <View style={{padding:20,gap:12}}>
    <Text style={{fontSize:28,fontWeight:'800'}}>Your LIFEOS account</Text>
    {session ? <>
      <Text>Signed in as {session.user?.email || 'local user'}</Text>
      <Pressable onPress={logout} disabled={busy} style={{padding:14,borderRadius:12,backgroundColor:'#111827'}}>
        {busy ? <ActivityIndicator color="#fff"/> : <Text style={{color:'#fff',fontWeight:'700',textAlign:'center'}}>Sign out</Text>}
      </Pressable>
      <Pressable onPress={deleteAccountData} disabled={busy} style={{padding:14,borderRadius:12,borderWidth:1,borderColor:'#ef4444'}}>
        <Text style={{color:'#b91c1c',fontWeight:'700',textAlign:'center'}}>Delete my LIFEOS cloud data</Text>
      </Pressable>
    </> : <>
      <TextInput autoCapitalize="none" keyboardType="email-address" placeholder="Email" value={email} onChangeText={setEmail} style={{borderWidth:1,borderColor:'#d1d5db',borderRadius:12,padding:14}}/>
      <TextInput secureTextEntry placeholder="Password" value={password} onChangeText={setPassword} style={{borderWidth:1,borderColor:'#d1d5db',borderRadius:12,padding:14}}/>
      <Pressable onPress={submit} disabled={busy} style={{padding:14,borderRadius:12,backgroundColor:'#111827'}}>
        {busy ? <ActivityIndicator color="#fff"/> : <Text style={{color:'#fff',fontWeight:'700',textAlign:'center'}}>{mode==='signin'?'Sign in':'Create account'}</Text>}
      </Pressable>
      {mode==='signin' && <Pressable onPress={resetPassword}>
        <Text style={{textAlign:'center',fontWeight:'700'}}>Forgot password?</Text>
      </Pressable>}
      <Pressable onPress={()=>setMode(mode==='signin'?'signup':'signin')}>
        <Text style={{textAlign:'center',fontWeight:'700'}}>{mode==='signin'?'Create a new account':'I already have an account'}</Text>
      </Pressable>
    </>}
    {!!status && <Text style={{marginTop:6}}>{status}</Text>}
    <Text style={{fontSize:12,color:'#6b7280'}}>Mode: {backendMode()}</Text>
  </View>
}
