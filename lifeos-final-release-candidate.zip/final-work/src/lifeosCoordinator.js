import {extractDocument} from './documentIntelligence';
import {getStoredItems,saveStoredItems} from './backend';
import {ingestDocument,buildRadar} from './lifeosDomain';
export async function ingestAndSaveDocument(text){const result=ingestDocument(text,extractDocument);if(!result.ok)return result;const current=await getStoredItems();const next=[result.item,...current];await saveStoredItems(next);return{...result,items:next,radar:buildRadar(next)};}
export async function getLifeOSRadar(today){const items=await getStoredItems();return{items,radar:buildRadar(items,today)};}
