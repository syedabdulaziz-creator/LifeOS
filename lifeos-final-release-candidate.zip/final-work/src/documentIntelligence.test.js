
const {extractDocument,answerDocumentQuestion}=require('./documentIntelligence.testable.js');
function assert(x,msg){if(!x)throw new Error(msg)}
const receipt=`Amazon\nAirPods Pro 2\nPurchase date: Sep 20, 2026\nTotal: $249.99\nReturn by: Oct 4, 2026`;
let r=extractDocument(receipt);assert(r.ok,'receipt ok');assert(r.fields.type==='receipt','receipt type');assert(r.fields.amount===249.99,'receipt amount');assert(r.fields.deadline==='2026-10-04','receipt deadline');
const sub=`Netflix\nMonthly plan\n$22.99\nNext billing: Oct 15, 2026\nRenews monthly`;
r=extractDocument(sub);assert(r.fields.type==='subscription','subscription type');assert(r.fields.amount===22.99,'subscription amount');assert(r.fields.renewalDate==='2026-10-15','renewal');
const bill=`Internet Service\nAmount due $69.00\nDue date: 10/10/2026`;
r=extractDocument(bill);assert(r.fields.type==='bill','bill type');assert(r.fields.deadline==='2026-10-10','bill deadline');
const warranty=`Laptop warranty\nCoverage until: Dec 20, 2027`;
r=extractDocument(warranty);assert(r.fields.type==='warranty','warranty type');assert(r.fields.warranty==='2027-12-20','warranty date');
r=answerDocumentQuestion(receipt,'When is the return deadline?');assert(r.answer==='2026-10-04','question deadline');
r=answerDocumentQuestion(receipt,'How much did I pay?');assert(r.answer==='$249.99','question amount');
r=extractDocument('');assert(!r.ok,'empty rejected');
console.log('document intelligence tests: PASS');
