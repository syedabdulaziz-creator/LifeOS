function money(n){return '$'+Number(n||0).toFixed(2)}
function daysText(n){return n===0?'Today':n===1?'Tomorrow':n==null||n>900?'Not set':n<0?`${Math.abs(n)} day${n===-1?'':'s'} overdue`:`in ${n} days`}
function daysUntil(value){
  if(!value)return 9999;
  const d=new Date(value);
  if(Number.isNaN(d.getTime())){
    const m=String(value).match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2})(?:,\s*(\d{4}))?$/i);
    if(!m)return 9999;
    const y=m[3]?Number(m[3]):new Date().getFullYear();
    const p=new Date(`${m[1]} ${m[2]}, ${y}`); if(Number.isNaN(p.getTime()))return 9999; return diffDays(p);
  }
  return diffDays(d);
}
function diffDays(d){const today=new Date();today.setHours(0,0,0,0);d.setHours(0,0,0,0);return Math.ceil((d-today)/86400000)}
function radarItems(items){return (items||[]).map(x=>({...x,daysLive:x.daysLive??x.days??daysUntil(x.deadline)})).sort((a,b)=>(a.daysLive??9999)-(b.daysLive??9999))}
function getTodayBriefing(items){return radarItems(items).filter(x=>x.daysLive<=7).slice(0,3)}
function answerPersonalMemory(items,question){
 const q=String(question||'').toLowerCase().trim();
 if(!q)return {title:'Ask anything',body:'Try asking about subscriptions, deadlines, warranties, purchases, or what needs attention.'};
 const list=items||[];
 const subscriptions=list.filter(x=>/subscription/i.test(x.type||''));
 const deadlines=list.filter(x=>x.deadline);
 const warranties=list.filter(x=>x.warranty);
 if(/subscription|recurring|monthly payment/.test(q)){
   return subscriptions.length?{title:'Your subscriptions',body:`${subscriptions.length} tracked subscription${subscriptions.length===1?'':'s'}, totaling ${money(subscriptions.reduce((sum,x)=>sum+Number(x.amount||0),0))} per month.\n\n${subscriptions.map(x=>`• ${x.title} — ${money(x.amount)}/month`).join('\n')}`}:{title:'Subscriptions',body:'I don’t have any tracked subscriptions yet.'};
 }
 if(/deadline|due|expir|renew/.test(q)){
   const live=radarItems(deadlines).slice(0,8); return live.length?{title:'Your upcoming dates',body:live.map(x=>`• ${x.title} — ${x.deadlineLabel||'Deadline'}: ${daysText(x.daysLive)}`).join('\n')}:{title:'Deadlines',body:'I don’t have any tracked deadlines yet.'};
 }
 if(/warranty|warranties|coverage/.test(q)) return warranties.length?{title:'Your warranties',body:warranties.map(x=>`• ${x.title} — warranty ${x.warranty}`).join('\n')}:{title:'Warranties',body:'I don’t have any warranty information saved yet.'};
 if(/purchase|bought|buy|receipt|order|amazon|spent|spend/.test(q)){
   const purchases=list.filter(x=>/purchase|receipt/i.test(x.type||'')||/amazon|receipt|order/i.test(`${x.merchant||''} ${x.title||''}`));
   return purchases.length?{title:'Matching purchases',body:purchases.slice(0,8).map(x=>`• ${x.title} — ${x.merchant||'Unknown merchant'} · ${money(x.amount)}`).join('\n')}:{title:'Purchases',body:'I don’t have a matching purchase saved yet.'};
 }
 if(/today|this week|attention|important|urgent/.test(q)){
   const important=getTodayBriefing(list); return important.length?{title:'What matters',body:important.map(x=>`• ${x.title} — ${x.deadlineLabel||'Deadline'} ${daysText(x.daysLive)}`).join('\n')}:{title:'What matters',body:'Nothing urgent is currently tracked.'};
 }
 const terms=q.split(/\s+/).filter(x=>x.length>2);
 const matches=list.filter(x=>terms.some(t=>`${x.title||''} ${x.merchant||''} ${x.type||''} ${x.deadlineLabel||''} ${x.warranty||''}`.toLowerCase().includes(t))).slice(0,8);
 return matches.length?{title:'I found these',body:matches.map(x=>`• ${x.title} — ${x.merchant||x.type||'Saved item'}`).join('\n')}:{title:'I couldn’t find that yet',body:'Try a more specific question, or add the document, receipt, bill, or subscription to LIFEOS first.'};
}
export {answerPersonalMemory,radarItems,getTodayBriefing,daysUntil};
