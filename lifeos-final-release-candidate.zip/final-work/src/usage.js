import AsyncStorage from '@react-native-async-storage/async-storage';
import {defaultUsage,normalizeUsage,recordUsage} from './entitlements';

const USAGE_KEY = 'lifeos_usage';

async function getUsage() {
  const raw = await AsyncStorage.getItem(USAGE_KEY);
  if (!raw) return defaultUsage();
  try { return normalizeUsage(JSON.parse(raw)); } catch (_) { return defaultUsage(); }
}

async function consumeUsage(resource) {
  const next = recordUsage(await getUsage(), resource);
  await AsyncStorage.setItem(USAGE_KEY, JSON.stringify(next));
  return next;
}

export {USAGE_KEY,getUsage,consumeUsage};
