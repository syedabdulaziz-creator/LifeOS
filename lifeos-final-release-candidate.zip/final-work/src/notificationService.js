
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { buildNotificationPlan } from './notificationEngine';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export async function requestNotificationPermission(){
  const current=await Notifications.getPermissionsAsync();
  if(current.status==='granted') return true;
  const requested=await Notifications.requestPermissionsAsync();
  return requested.status==='granted';
}

export async function configureAndroidChannel(){
  if(Platform.OS!=='android') return;
  await Notifications.setNotificationChannelAsync('lifeos-deadlines',{
    name:'LIFEOS reminders',
    importance:Notifications.AndroidImportance.DEFAULT,
    sound:null,
  });
}

export async function clearLifeOSNotifications(){
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function scheduleLifeOSNotifications(items,{requestPermission=false}={}){
  const current=await Notifications.getPermissionsAsync();
  const allowed=current.status==='granted' || (requestPermission && await requestNotificationPermission());
  if(!allowed) return {scheduled:0,permission:false};
  await configureAndroidChannel();
  await clearLifeOSNotifications();

  const plan=buildNotificationPlan(items);
  let scheduled=0;
  for(const event of plan){
    const d=new Date(`${event.date}T09:00:00`);
    d.setDate(d.getDate()-event.daysBefore);
    if(d.getTime()<=Date.now()) continue;
    await Notifications.scheduleNotificationAsync({
      content:{
        title:event.title,
        body:event.body,
        data:{lifeos:true,itemId:event.itemId,kind:event.kind},
      },
      trigger:{type:Notifications.SchedulableTriggerInputTypes.DATE,date:d},
    });
    scheduled++;
  }
  return {scheduled,permission:true};
}
