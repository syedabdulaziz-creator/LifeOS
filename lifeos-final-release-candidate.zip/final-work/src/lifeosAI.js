import {extractDocument,answerDocumentQuestion} from './documentIntelligence';
import {answerPersonalMemory as answerMemory} from './memoryEngine';
import {getConfiguredProvider,callRemoteAI} from './aiProvider';

function cleanQuestion(question=''){return String(question).replace(/\s+/g,' ').trim().slice(0,500);}
function localDocumentAnalysis(text){
  const result=extractDocument(text);
  if(!result.ok)return result;
  return {...result,provider:'local',mode:'deterministic'};
}

async function analyzeDocument(text){
  if(getConfiguredProvider()==='remote'){
    try{return {...await callRemoteAI({task:'extract_document',text:String(text||'').slice(0,30000)}),provider:'remote'};}
    catch(error){return {...localDocumentAnalysis(text),fallback:true,providerError:error.message};}
  }
  return localDocumentAnalysis(text);
}

async function answerDocument(text,question){
  const q=cleanQuestion(question);
  if(!q)return {answer:'Ask me something about this document.'};
  if(getConfiguredProvider()==='remote'){
    try{return {...await callRemoteAI({task:'answer_document',text:String(text||'').slice(0,30000),question:q}),provider:'remote'};}
    catch(error){return {...answerDocumentQuestion(text,q),fallback:true,providerError:error.message};}
  }
  return {...answerDocumentQuestion(text,q),provider:'local'};
}

function answerPersonalMemory(items,question){
  const q=cleanQuestion(question);
  if(!q)return {title:'Ask LIFEOS',body:'Ask me about something you saved.'};
  return {...answerMemory(items,q),provider:'local'};
}

function toLifeOSItem(fields={}){
  const typeMap={receipt:'Purchase',subscription:'Subscription',bill:'Bill',warranty:'Warranty',document:'Document'};
  const type=typeMap[fields.type]||'Document';
  return {title:fields.title||'Imported document',type,merchant:fields.merchant||'Imported',amount:Number(fields.amount||0),date:fields.purchaseDate||new Date().toISOString().slice(0,10),deadline:fields.deadline||'Not detected yet',deadlineLabel:fields.deadlineLabel||'Review required',days:fields.deadline?Math.ceil((new Date(fields.deadline)-new Date())/86400000):999,warranty:fields.warranty||null,renewalDate:fields.renewalDate||null,status:'active',icon:type==='Subscription'?'repeat':type==='Purchase'?'receipt':type==='Warranty'?'shield-check-outline':'file-document-outline'};
}

function buildAIContext(items){
  return (items||[]).slice(0,100).map(item=>({id:item.id,title:item.title||null,merchant:item.merchant||null,type:item.type||null,amount:item.amount??null,currency:item.currency||'USD',deadline:item.deadline||null,deadlineLabel:item.deadlineLabel||null,renewalDate:item.renewalDate||null,warranty:item.warranty||null}));
}

export {analyzeDocument,answerDocument,answerPersonalMemory,buildAIContext,cleanQuestion,toLifeOSItem};
