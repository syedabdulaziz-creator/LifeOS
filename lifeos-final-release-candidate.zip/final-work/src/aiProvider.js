const LOCAL_PROVIDER = 'local';

function getConfiguredProvider(){
  const provider = (process.env.EXPO_PUBLIC_LIFEOS_AI_PROVIDER || LOCAL_PROVIDER).toLowerCase();
  return provider === 'remote' ? 'remote' : LOCAL_PROVIDER;
}

function getRemoteEndpoint(){
  return process.env.EXPO_PUBLIC_LIFEOS_AI_ENDPOINT || '';
}

async function callRemoteAI(payload){
  const endpoint = getRemoteEndpoint();
  if(!endpoint) throw new Error('AI endpoint is not configured. LIFEOS is using its local AI engine.');
  const response = await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(!response.ok) throw new Error(`AI service returned ${response.status}.`);
  const data = await response.json();
  if(!data || typeof data !== 'object') throw new Error('AI service returned an invalid response.');
  return data;
}

export {LOCAL_PROVIDER,getConfiguredProvider,getRemoteEndpoint,callRemoteAI};
