import React,{useState} from 'react';
import {View,Text,Pressable,ActivityIndicator} from 'react-native';
import {refreshLifeOSMonitoring} from './monitoringCoordinator';

export default function MonitoringScreen({close}){
  const [busy,setBusy]=useState(false);
  const [status,setStatus]=useState('');
  async function refresh(){
    try{
      setBusy(true);
      const r=await refreshLifeOSMonitoring(true);
      setStatus(r.permission?`${r.scheduled} LIFEOS reminders scheduled.`:'Notifications are not enabled.');
    }catch(e){setStatus(e?.message||'Could not refresh monitoring.');}
    finally{setBusy(false);}
  }
  return <View style={{padding:20,gap:12}}>
    <Text style={{fontSize:28,fontWeight:'800'}}>Monitoring</Text>
    <Text style={{color:'#6b7280'}}>LIFEOS checks saved deadlines, renewals and warranties and schedules timely reminders.</Text>
    <Pressable disabled={busy} onPress={refresh} style={{padding:14,borderRadius:12,backgroundColor:'#111827'}}>
      {busy?<ActivityIndicator color="#fff"/>:<Text style={{color:'#fff',textAlign:'center',fontWeight:'800'}}>Enable & refresh reminders</Text>}
    </Pressable>
    {!!status&&<Text>{status}</Text>}
    <Pressable onPress={close} style={{padding:14}}><Text style={{textAlign:'center'}}>Done</Text></Pressable>
  </View>;
}
