import { PDFDocument } from 'pdf-lib';
import * as FileSystem from 'expo-file-system/legacy';

function bytesToBase64(bytes){
  const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let out='';
  for(let i=0;i<bytes.length;i+=3){
    const a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;
    const n=(a<<16)|(b<<8)|c;
    out+=chars[(n>>18)&63]+chars[(n>>12)&63]+(i+1<bytes.length?chars[(n>>6)&63]:'=')+(i+2<bytes.length?chars[n&63]:'=');
  }
  return out;
}

async function readBytes(uri){
  const response=await fetch(uri);
  if(!response.ok) throw new Error('Could not read the selected PDF.');
  return new Uint8Array(await response.arrayBuffer());
}

async function writePdf(bytes,name){
  const dir=FileSystem.documentDirectory;
  if(!dir) throw new Error('Local document storage is unavailable.');
  const safe=String(name||'lifeos-document.pdf').replace(/[^a-zA-Z0-9._-]/g,'_');
  const uri=`${dir}${Date.now()}-${safe}`;
  await FileSystem.writeAsStringAsync(uri,bytesToBase64(bytes),{encoding:FileSystem.EncodingType.Base64});
  return uri;
}

export async function mergePdfs(uris){
  if(!uris||uris.length<2) throw new Error('Choose at least two PDF files.');
  const output=await PDFDocument.create();
  for(const uri of uris){
    const source=await PDFDocument.load(await readBytes(uri));
    const pages=await output.copyPages(source,source.getPageIndices());
    pages.forEach(page=>output.addPage(page));
  }
  return writePdf(await output.save({useObjectStreams:true}),'lifeos-merged.pdf');
}

export async function splitPdf(uri,pageNumbers){
  const source=await PDFDocument.load(await readBytes(uri));
  const total=source.getPageCount();
  const requested=[...new Set((pageNumbers||[]).map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=total))];
  if(!requested.length) throw new Error(`Choose page numbers from 1 to ${total}.`);
  const output=await PDFDocument.create();
  const pages=await output.copyPages(source,requested.map(n=>n-1));
  pages.forEach(page=>output.addPage(page));
  return writePdf(await output.save({useObjectStreams:true}),`lifeos-pages-${requested.join('-')}.pdf`);
}

export async function compressPdf(uri){
  const source=await PDFDocument.load(await readBytes(uri));
  const bytes=await source.save({useObjectStreams:true,addDefaultPage:false});
  return writePdf(bytes,'lifeos-optimized.pdf');
}
