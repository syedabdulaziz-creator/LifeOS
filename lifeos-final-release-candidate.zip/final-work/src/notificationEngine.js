
function parseDay(v){
  if(!v)return null;
  const raw=String(v).trim();
  const iso=/^\d{4}-\d{2}-\d{2}$/.test(raw);
  const d=iso?new Date(`${raw}T00:00:00`):new Date(raw);
  return Number.isNaN(d.getTime())?null:d;
}
function daysUntil(dateString,today=new Date().toISOString().slice(0,10)){const a=parseDay(today),b=parseDay(dateString);if(!a||!b)return null;return Math.ceil((b-a)/86400000);}
function notificationDate(dateString, daysBefore=1){
  const d=parseDay(dateString); if(!d)return null;
  d.setDate(d.getDate()-daysBefore);
  return d.toISOString().slice(0,10);
}
function notificationCandidates(item){
  const out=[];
  if(item.deadline){
    const d=daysUntil(item.deadline);
    if(d!==null && d>=0){
      if(d===0) out.push({kind:'deadline-today',date:item.deadline,daysBefore:0,title:item.deadlineLabel||'Deadline today',body:`${item.title} needs attention today.`});
      else if(d<=7) out.push({kind:'deadline',date:item.deadline,daysBefore:1,title:item.deadlineLabel||'Deadline approaching',body:`${item.title} is due tomorrow.`});
    }
  }
  if(item.renewalDate){
    const d=daysUntil(item.renewalDate);
    if(d!==null && d>=0 && d<=7){
      out.push({kind:'renewal',date:item.renewalDate,daysBefore:1,title:'Renewal approaching',body:`${item.title} renews tomorrow.`});
    }
  }
  if(item.warranty && /^\d{4}-\d{2}-\d{2}$/.test(item.warranty)){
    const d=daysUntil(item.warranty);
    if(d!==null && d>=0 && d<=7){
      out.push({kind:'warranty',date:item.warranty,daysBefore:1,title:'Warranty approaching',body:`${item.title} warranty expires tomorrow.`});
    }
  }
  return out;
}
function notificationKey(item,event){return `lifeos:${item.id}:${event.kind}:${event.date}`;}
export function buildNotificationPlan(items){
  const plan=[];
  for(const item of items||[]){
    for(const event of notificationCandidates(item)){
      plan.push({...event,itemId:item.id,key:notificationKey(item,event)});
    }
  }
  return plan;
}
export function shouldNotify(item,event,today=new Date().toISOString().slice(0,10)){
  if(!item||!event)return false;
  if(event.date===today)return event.kind==='deadline-today';
  return notificationDate(event.date,event.daysBefore)===today;
}
