import {FREE_LIMITS,defaultUsage,normalizeUsage,canUse,recordUsage,remaining} from './entitlements.js';

const assert=(condition,message)=>{if(!condition)throw new Error(message)};

assert(FREE_LIMITS.savedItems===50,'saved item limit changed unexpectedly');
assert(canUse({isPro:false},defaultUsage(),'savedItems',49),'49 saved items should be allowed');
assert(!canUse({isPro:false},defaultUsage(),'savedItems',50),'50 saved items should be blocked');
assert(canUse({isPro:true},defaultUsage(),'savedItems',999),'Pro should bypass saved item limit');
let usage=defaultUsage();
for(let i=0;i<10;i++) usage=recordUsage(usage,'aiAnalyses');
assert(!canUse({isPro:false},usage,'aiAnalyses'),'AI limit should block after 10');
assert(remaining(usage,'aiAnalyses')===0,'AI remaining should be zero');
const old={month:'2020-01',aiAnalyses:99,pdfOperations:99};
assert(normalizeUsage(old).aiAnalyses===0,'old month usage should reset');
assert(recordUsage(defaultUsage(),'pdfOperations').pdfOperations===1,'PDF usage should increment');
assert(canUse({isPro:true},usage,'pdfOperations'),'Pro should bypass PDF limit');
console.log('monetization tests passed');
