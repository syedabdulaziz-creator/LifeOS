
const {validateInput,describeOperation}=require('./pdfToolkit');
if(!validateInput('receipt.pdf').isPdf) throw Error('PDF detection failed');
if(!validateInput('photo.JPG').isImage) throw Error('image detection failed');
if(validateInput('virus.exe').supported) throw Error('unsupported extension accepted');
if(describeOperation('merge',[]).ok) throw Error('empty merge accepted');
if(describeOperation('merge',['a.pdf']).ok) throw Error('single-file merge accepted');
if(!describeOperation('merge',['a.pdf','b.pdf']).ok) throw Error('valid merge rejected');
if(describeOperation('convert',['a.exe']).ok) throw Error('invalid conversion accepted');
console.log('PDF toolkit validation tests: PASS');
