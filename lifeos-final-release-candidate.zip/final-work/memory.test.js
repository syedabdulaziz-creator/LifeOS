
function money(n){return '$'+Number(n||0).toFixed(2)}
function daysText(n){return n===0?'Today':n===1?'Tomorrow':n>900?'Not set':`in ${n} days`}
function radarItems(items){return items.map(x=>({...x,daysLive:x.days})).sort((a,b)=>(a.daysLive??9999)-(b.daysLive??9999))}
function getTodayBriefingFallback(items){return radarItems(items).filter(x=>x.daysLive==null||x.daysLive<=7).slice(0,3)}
function askLIFEOS(items,q){
 const s=q.toLowerCase().trim();
 const subs=items.filter(x=>/subscription/i.test(x.type||''));
 if(/subscription|recurring|monthly payment/.test(s))
   return subs.length?`${subs.length} tracked subscription(s), totaling ${money(subs.reduce((a,x)=>a+Number(x.amount||0),0))} per month.`:'I don’t have any tracked subscriptions yet.';
 if(/deadline|due|expir|renew/.test(s)) return radarItems(items.filter(x=>x.deadline)).slice(0,8).map(x=>x.title).join('|')||'I don’t have any tracked deadlines yet.';
 if(/warranty|warranties/.test(s)) return items.filter(x=>x.warranty).map(x=>x.title).join('|')||'I don’t have any warranty information saved yet.';
 if(/today|this week|attention|important/.test(s)) return getTodayBriefingFallback(items).map(x=>x.title).join('|')||'Nothing urgent is currently tracked.';
 return 'I couldn’t find that yet';
}
const data=[
 {title:'AirPods Pro',type:'Purchase',merchant:'Amazon',amount:249,deadline:'Oct 17',deadlineLabel:'Return deadline',days:3,warranty:'Sep 2027'},
 {title:'Adobe Creative Cloud',type:'Subscription',merchant:'Adobe',amount:59.99,deadline:'Oct 1',days:1},
 {title:'Auto insurance',type:'Renewal',merchant:'GEICO',amount:128,deadline:'Oct 8',days:8}
];
if(!askLIFEOS(data,'What subscriptions am I paying for?').includes('$59.99'))throw Error('subscription query failed');
if(!askLIFEOS(data,'What deadlines are coming up?').includes('AirPods Pro'))throw Error('deadline query failed');
if(!askLIFEOS(data,'What warranties do I have?').includes('AirPods Pro'))throw Error('warranty query failed');
if(!askLIFEOS(data,'What should I take care of this week?').includes('Adobe Creative Cloud'))throw Error('today query failed');
console.log('Memory query tests: PASS');
