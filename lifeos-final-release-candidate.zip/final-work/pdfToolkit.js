
const SUPPORTED_EXTENSIONS = ['pdf','png','jpg','jpeg','webp','txt'];

function extension(name=''){
  const parts=String(name).toLowerCase().split('.');
  return parts.length>1 ? parts.pop() : '';
}

function validateInput(name){
  const ext=extension(name);
  return {
    extension: ext,
    supported: SUPPORTED_EXTENSIONS.includes(ext),
    isPdf: ext==='pdf',
    isImage: ['png','jpg','jpeg','webp'].includes(ext),
    isText: ext==='txt'
  };
}

function describeOperation(operation, fileNames=[]){
  const files=fileNames.filter(Boolean);
  if(!files.length) return {ok:false,message:'Choose at least one file.'};
  if(operation==='merge' && files.length<2) return {ok:false,message:'Choose at least two PDF files to merge.'};
  const invalid=files.filter(name=>!validateInput(name).supported);
  if(invalid.length) return {ok:false,message:`Unsupported file type: ${invalid[0]}`};
  return {ok:true,message:`Ready to ${operation} ${files.length} file${files.length===1?'':'s'}.`};
}

module.exports={SUPPORTED_EXTENSIONS,extension,validateInput,describeOperation};
