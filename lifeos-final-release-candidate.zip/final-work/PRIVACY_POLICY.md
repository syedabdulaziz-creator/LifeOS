# LIFEOS Privacy Policy

**Last updated: September 27, 2026**

LIFEOS is a personal memory, document, deadline and reminder app.

## Information LIFEOS can process

Depending on the features you use, LIFEOS may process text, photos, documents, purchase information, dates, reminders, account information and app settings that you provide.

## Local processing

LIFEOS is designed to process as much information as possible on your device. Local extraction, OCR and deterministic intelligence can operate without sending document contents to a third-party AI service.

## Cloud account and sync

If you create an account and enable cloud sync, LIFEOS may store your LIFEOS items in its configured backend so they can be synchronized across supported devices. Authentication and database access are protected by user-level access controls.

## AI processing

The release candidate defaults to local/free-first document intelligence. If a remote AI provider is enabled in a future release, LIFEOS will clearly identify the applicable provider and the relevant data-processing terms before using that provider for remote analysis.

## Notifications

If you enable reminders, LIFEOS schedules notifications for dates you asked it to monitor. Notification permissions can be controlled through your device settings.

## Purchases

LIFEOS Pro subscriptions, when enabled, are processed through Apple App Store and/or Google Play and the configured subscription provider. LIFEOS does not receive your full payment-card details.

## Data deletion

You can delete your LIFEOS cloud data from the account controls where cloud sync is enabled. Full authentication-account deletion may require the configured backend account-deletion flow.

## Contact

For privacy questions, use the support contact published on the official LIFEOS store listing.
