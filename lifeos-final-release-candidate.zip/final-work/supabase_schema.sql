
-- LIFEOS production schema
-- Run this migration in a Supabase project before enabling cloud mode.

create extension if not exists pgcrypto;

create table if not exists public.lifeos_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  merchant text,
  item_type text,
  amount numeric,
  currency text default 'USD',
  purchase_date date,
  deadline date,
  deadline_label text,
  renewal_date date,
  warranty text,
  source text,
  source_name text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists lifeos_items_user_id_idx
  on public.lifeos_items(user_id);

create index if not exists lifeos_items_deadline_idx
  on public.lifeos_items(user_id, deadline);

alter table public.lifeos_items enable row level security;

drop policy if exists "Users can read their own LIFEOS items" on public.lifeos_items;
create policy "Users can read their own LIFEOS items"
  on public.lifeos_items for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert their own LIFEOS items" on public.lifeos_items;
create policy "Users can insert their own LIFEOS items"
  on public.lifeos_items for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own LIFEOS items" on public.lifeos_items;
create policy "Users can update their own LIFEOS items"
  on public.lifeos_items for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own LIFEOS items" on public.lifeos_items;
create policy "Users can delete their own LIFEOS items"
  on public.lifeos_items for delete
  using (auth.uid() = user_id);
