import React, {useEffect, useMemo, useState} from 'react';
import {Alert, FlatList, KeyboardAvoidingView, Modal, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import TextRecognition from '@react-native-ml-kit/text-recognition';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import AccountScreen from './src/AccountScreen';
import {refreshLifeOSMonitoring} from './src/monitoringCoordinator';
import MonitoringScreen from './src/MonitoringScreen';
import ProScreen from './src/ProScreen';
import {getEntitlement,initializeBilling} from './src/billing';
import {canUse,normalizeUsage} from './src/entitlements';
import {getUsage,consumeUsage} from './src/usage';
import {mergePdfs,splitPdf,compressPdf} from './src/pdfEngine';
import {analyzeDocument,answerPersonalMemory as aiAnswerPersonalMemory,toLifeOSItem} from './src/lifeosAI';

const seed=[
 {id:'1',title:'AirPods Pro',type:'Purchase',merchant:'Amazon',amount:249,date:'Sep 17, 2026',deadline:'Oct 17, 2026',deadlineLabel:'Return deadline',days:20,status:'active',icon:'headphones'},
 {id:'2',title:'Auto insurance',type:'Renewal',merchant:'GEICO',amount:128,date:'Aug 12, 2026',deadline:'Oct 8, 2026',deadlineLabel:'Renewal',days:11,status:'active',icon:'car-outline'},
 {id:'3',title:'Adobe Creative Cloud',type:'Subscription',merchant:'Adobe',amount:59.99,date:'Sep 1, 2026',deadline:'Oct 1, 2026',deadlineLabel:'Renewal',days:4,status:'active',icon:'palette-outline'}
];

function money(n){return '$'+Number(n||0).toFixed(2)}
function daysText(n){return n===0?'Today':n===1?'Tomorrow':n>900?'Not set':`in ${n} days`}
function dateFromText(value){
  if(!value)return null;
  const d=new Date(value);
  if(!Number.isNaN(d.getTime()))return d;
  const m=value.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{1,2})(?:,\s*(\d{4}))?/i);
  if(!m)return null;
  const year=m[3]?Number(m[3]):new Date().getFullYear();
  const parsed=new Date(`${m[1]} ${m[2]}, ${year}`);
  return Number.isNaN(parsed.getTime())?null:parsed;
}
function daysUntil(value){
  const d=dateFromText(value); if(!d)return 999;
  const today=new Date(); today.setHours(0,0,0,0); d.setHours(0,0,0,0);
  return Math.max(0,Math.ceil((d-today)/86400000));
}

function radarItems(items){
  return items.map(x=>{
    const d=daysUntil(x.deadline);
    return {...x, daysLive:d==null?x.days:d};
  }).sort((a,b)=>(a.daysLive??9999)-(b.daysLive??9999));
}
function urgency(days){
  if(days==null || days>30) return {label:'Later', color:'#7C8FFF'};
  if(days<0) return {label:'Overdue', color:'#F04438'};
  if(days===0) return {label:'Today', color:'#F04438'};
  if(days===1) return {label:'Tomorrow', color:'#F5A524'};
  if(days<=7) return {label:'This week', color:'#F5A524'};
  return {label:'Upcoming', color:'#34A853'};
}
function moneyRadar(items){
  const subs=items.filter(x=>x.type==='Subscription' && Number(x.amount)>0);
  return {
    monthly:subs.reduce((sum,x)=>sum+Number(x.amount||0),0),
    count:subs.length,
    upcoming:subs.filter(x=>x.daysLive!=null && x.daysLive>=0 && x.daysLive<=30).length
  };
}
function parseDocumentText(text){
  const raw=String(text||'').trim();
  const lower=raw.toLowerCase();
  const amountMatch=raw.match(/(?:\$|usd\s*)(\d{1,5}(?:,\d{3})*(?:\.\d{1,2})?)/i);
  const amount=amountMatch?Number(amountMatch[1].replace(/,/g,'')):0;
  const returnMatch=raw.match(/(?:return(?:\s+window|\s+by|\s+deadline)?|returns?\s+by)\D{0,25}((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?)/i);
  const warrantyMatch=raw.match(/warranty\D{0,25}((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?)/i);
  const renewalMatch=raw.match(/(?:renew(?:al)?|renews?)\D{0,25}((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?)/i);
  const dateMatch=returnMatch||renewalMatch||warrantyMatch;
  const lines=raw.split(/\n|\r/).map(x=>x.trim()).filter(x=>x.length>2);
  const merchant=((raw.match(/(?:from|merchant|store)\s*[:\-]?\s*([^\n]+)/i)||[])[1]?.trim()) || (lines.length>1 && !/^[$\d]/.test(lines[0]) ? lines[0] : 'Imported');
  const type=lower.includes('subscription')||lower.includes('renew')?'Subscription':(lower.includes('return')||lower.includes('receipt')||lower.includes('order'))?'Purchase':lower.includes('warranty')?'Warranty':'Document';
  const title=(type==='Purchase' && lines.length>1 && merchant===lines[0])?lines[1]:lines[0] || 'Imported document';
  const deadline=dateMatch?dateMatch[1]:null;
  const deadlineLabel=returnMatch?'Return deadline':renewalMatch?'Renewal':warrantyMatch?'Warranty':'Review required';
  return {title:title.slice(0,60),type,merchant:merchant.slice(0,50),amount,date:new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}),deadline:deadline||'Not detected yet',deadlineLabel,days:deadline?daysUntil(deadline):999,status:'active',icon:type==='Subscription'?'repeat':type==='Purchase'?'receipt':type==='Warranty'?'shield-check-outline':'file-document-outline',rawText:raw};
}

async function extractImageWithOCR(uri){
  if(!uri)throw new Error('Missing image');
  const result=await TextRecognition.recognize(uri);
  const text=String(result?.text||'').trim();
  if(!text)throw new Error('No readable text found');
  return text;
}

export default function App(){
 const [tab,setTab]=useState('Today');
 const [items,setItems]=useState(seed);
 const [modal,setModal]=useState(null);
 const [selected,setSelected]=useState(null);
 const [query,setQuery]=useState('');
 const [ready,setReady]=useState(false);
 const [pending,setPending]=useState(null);
 const [pasteText,setPasteText]=useState('');
 const [entitlement,setEntitlement]=useState({isPro:false});
 const [usage,setUsage]=useState(normalizeUsage(null));
 useEffect(()=>{(async()=>{try{const raw=await AsyncStorage.getItem('lifeos_items');if(raw){const loaded=JSON.parse(raw);setItems(loaded);try{await refreshLifeOSMonitoring(false)}catch(e){}} try{await initializeBilling()}catch(e){} setEntitlement(await getEntitlement()); setUsage(await getUsage());}finally{setReady(true)}})()},[]);
 useEffect(()=>{if(ready)AsyncStorage.setItem('lifeos_items',JSON.stringify(items))},[items,ready]);
 const filtered=useMemo(()=>items.filter(x=>(x.title+' '+x.merchant+' '+x.type).toLowerCase().includes(query.toLowerCase())),[items,query]);
 const total=items.filter(x=>x.type==='Subscription').reduce((a,x)=>a+Number(x.amount||0),0);
 const openPro=()=>setModal('pro');
 const runAnalysis=async(text)=>{
   const current=await getEntitlement();
   const currentUsage=await getUsage();
   if(!canUse(current,currentUsage,'aiAnalyses')){
     setEntitlement(current); setUsage(currentUsage); setModal('pro');
     return null;
   }
   const result=await analyzeDocument(text);
   if(!current.isPro){ const next=await consumeUsage('aiAnalyses'); setUsage(next); }
   return result;
 };
 const addItem=async(item)=>{
   const current=await getEntitlement();
   if(!canUse(current,await getUsage(),'savedItems',items.length)){ setEntitlement(current); setModal('pro'); return; }
   const saved={...item,id:Date.now().toString(),days:item.deadline?daysUntil(item.deadline):999};
   const next=[saved,...items];
   setItems(next);
   setModal(null);
   try{await AsyncStorage.setItem('lifeos_items',JSON.stringify(next));}catch(e){}
   try{await refreshLifeOSMonitoring(false,next);}catch(e){}
 };
 const capture=async(kind)=>{
   try{
    if(kind==='paste'){
      setPasteText('');
      setModal('paste');
      return;
    }
    if(kind==='photo'){
      const p=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],quality:.8});
      if(!p.canceled){
        const uri=p.assets?.[0]?.uri||null;
        setPending({source:'image',name:'Imported image',uri});
        setModal('processing');
        try{
          const text=await extractImageWithOCR(uri);
          const analysis=await runAnalysis(text);
          if(!analysis){return;}
          const extracted=analysis.ok?{...toLifeOSItem(analysis.fields),aiProvider:analysis.provider,confidence:analysis.fields.confidence}:null;
          setPending({source:'image',name:extracted.title,uri,ocrText:text,extracted});
        }catch(e){
          setPending({source:'image',name:'Imported image',uri,ocrError:e?.message||'OCR unavailable'});
        }
        setModal('result');
      }
    } else if(kind==='camera'){
      const perm=await ImagePicker.requestCameraPermissionsAsync();
      if(!perm.granted){Alert.alert('Camera permission needed','Enable camera access to scan a document.');return}
      const p=await ImagePicker.launchCameraAsync({quality:.8});
      if(!p.canceled){
        const uri=p.assets?.[0]?.uri||null;
        setPending({source:'camera',name:'Camera capture',uri});
        setModal('processing');
        try{
          const text=await extractImageWithOCR(uri);
          const analysis=await runAnalysis(text);
          if(!analysis){return;}
          const extracted=analysis.ok?{...toLifeOSItem(analysis.fields),aiProvider:analysis.provider,confidence:analysis.fields.confidence}:null;
          setPending({source:'camera',name:extracted.title,uri,ocrText:text,extracted});
        }catch(e){
          setPending({source:'camera',name:'Camera capture',uri,ocrError:e?.message||'OCR unavailable'});
        }
        setModal('result');
      }
    } else {
      const r=await DocumentPicker.getDocumentAsync({type:['application/pdf','image/*','text/plain'],copyToCacheDirectory:true});
      if(!r.canceled){
        const asset=r.assets?.[0];
        const name=asset?.name||'Imported document';
        setPending({source:'file',name,uri:asset?.uri||null});
        setModal('processing');
        if((asset?.mimeType||'').includes('text/plain')){
          try{
            const response=await fetch(asset.uri);
            const text=await response.text();
            const analysis=await runAnalysis(text); if(!analysis){return;} const extracted=analysis.ok?{...toLifeOSItem(analysis.fields),aiProvider:analysis.provider,confidence:analysis.fields.confidence}:null;
            setPending({source:'file',name:extracted.title,uri:asset.uri,ocrText:text,extracted});
          }catch(e){setPending({source:'file',name,uri:asset?.uri||null,ocrError:'Could not read text file'});}
        }
        setModal('result');
      }
    }
   }catch(e){Alert.alert('Could not import','Please try again.');}
 };
 const saveExtracted=(extracted)=>addItem(extracted);
 const submitPaste=async()=>{
   if(!pasteText.trim()){Alert.alert('Add some text','Paste the receipt, bill, booking or document text first.');return;}
   const analysis=await runAnalysis(pasteText);
   if(!analysis)return;
   const extracted=analysis.ok?{...toLifeOSItem(analysis.fields),aiProvider:analysis.provider,confidence:analysis.fields.confidence}:null;
   setPending({source:'text',name:extracted.title,extracted});
   setPasteText('');
   setModal('result');
 };
 const saveDemo=()=>{
   if(pending?.extracted)return addItem(pending.extracted);
   if(pending?.source==='demo')return addItem({title:'AirPods Pro',type:'Purchase',merchant:'Amazon',amount:249,date:'Sep 17, 2026',deadline:'Oct 17, 2026',deadlineLabel:'Return deadline',days:daysUntil('Oct 17, 2026'),status:'active',icon:'headphones'});
   return addItem({title:pending?.name||'Imported document',type:'Document',merchant:'Imported',amount:0,date:new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}),deadline:'Not detected yet',deadlineLabel:'Review required',days:999,status:'active',icon:'file-document-outline'});
 };
 return <SafeAreaView style={s.safe}>
  <StatusBar barStyle="dark-content"/>
  <View style={s.top}><View><Text style={s.logo}>LIFEOS</Text><Text style={s.tag}>You live. We remember.</Text></View><Pressable onPress={()=>setModal('settings')} style={s.avatar}><Text style={s.avatarText}>A</Text></Pressable></View>
  {tab==='Today'&&<Today items={items} total={total} onAdd={()=>setModal('capture')} onOpen={x=>setSelected(x)}/>} 
  {tab==='Radar'&&<Radar items={items} onOpen={x=>setSelected(x)}/>} 
  {tab==='Ask'&&<Ask items={items}/>} 
  {tab==='Tools'&&<Tools onCapture={capture}/>} 
  {tab==='Memory'&&<Memory items={filtered} query={query} setQuery={setQuery} onOpen={x=>setSelected(x)}/>} 
  <View style={s.nav}>{[['Today','view-dashboard-outline'],['Radar','radar'],['Ask','message-text-outline'],['Tools','file-pdf-box'],['Memory','brain']].map(([name,icon])=><Pressable key={name} onPress={()=>setTab(name)} style={s.navItem}><MaterialCommunityIcons name={icon} size={23} color={tab===name?'#111827':'#9AA1AD'}/><Text style={[s.navText,tab===name&&s.navActive]}>{name}</Text></Pressable>)}</View>
  <Modal visible={!!modal} transparent animationType="slide" onRequestClose={()=>setModal(null)}>{modal==='capture'&&<Capture close={()=>setModal(null)} on={capture} onDemo={()=>{setPending({source:'demo',name:'AirPods Pro'});setModal('result')}}/>} {modal==='paste'&&<Paste close={()=>setModal(null)} value={pasteText} setValue={setPasteText} submit={submitPaste}/>} {modal==='processing'&&<Center><View style={s.processing}><MaterialCommunityIcons name="brain" size={42} color="#111827"/><Text style={s.processTitle}>Understanding this…</Text><Text style={s.muted}>Finding dates, amounts and actions.</Text></View></Center>} {modal==='result'&&<Result close={()=>setModal(null)} save={saveDemo} pending={pending}/>} {modal==='settings'&&<Settings close={()=>setModal(null)} openMonitoring={()=>setModal('monitoring')} openPro={openPro}/>} {modal==='monitoring'&&<MonitoringScreen close={()=>setModal(null)}/>} {modal==='pro'&&<ProScreen close={async()=>{setEntitlement(await getEntitlement());setUsage(await getUsage());setModal(null)}}/>}</Modal>
  <Modal visible={!!selected} transparent animationType="slide" onRequestClose={()=>setSelected(null)}>{selected&&<ItemDetail item={selected} close={()=>setSelected(null)}/>}</Modal>
 </SafeAreaView>
}

function Today({items,total,onAdd,onOpen}){
  const live=radarItems(items);
  const important=live.filter(x=>x.daysLive==null || x.daysLive<=30).slice(0,3);
  const money=moneyRadar(live);
  return <ScrollView contentContainerStyle={s.content}>
    <View style={s.greeting}><Text style={s.h1}>Good evening.</Text><Text style={s.sub}>Here are the things worth your attention.</Text></View>
    <Pressable style={s.captureHero} onPress={onAdd}><View style={s.captureIcon}><MaterialCommunityIcons name="plus" size={26} color="#fff"/></View><View style={{flex:1}}><Text style={s.captureTitle}>Add something</Text><Text style={s.captureSub}>Receipt, PDF, screenshot or document</Text></View><MaterialCommunityIcons name="chevron-right" size={24} color="#A7ADB8"/></Pressable>
    <Text style={s.section}>TODAY</Text>
    {important.length===0?<View style={s.emptyCard}><Text style={s.emptyTitle}>Nothing urgent.</Text><Text style={s.emptyText}>LIFEOS is watching your saved items.</Text></View>:important.map(x=>{const u=urgency(x.daysLive);return <Pressable key={x.id} onPress={()=>onOpen(x)} style={s.alertCard}><View style={[s.dot,{backgroundColor:u.color}]}/><View style={{flex:1}}><Text style={s.cardTitle}>{x.deadlineLabel||'Important date'}</Text><Text style={s.cardMain}>{x.title}</Text><Text style={s.cardSub}>{x.merchant||'Saved item'} · {money(x.amount)}</Text></View><Text style={s.when}>{u.label}</Text></Pressable>})}
    <Text style={s.section}>MONEY RADAR</Text>
    <View style={s.moneyCard}><View style={s.moneyRow}><Text style={s.moneyBig}>{money(money.monthly||total)}</Text><Text style={s.moneyLabel}>tracked monthly subscriptions</Text></View><Text style={s.moneyHint}>{money.count?`${money.count} subscription${money.count===1?'':'s'} tracked · ${money.upcoming} renewing soon.`:'No recurring subscriptions detected yet.'}</Text><Pressable onPress={()=>{const sub=live.find(x=>x.type==='Subscription');if(sub)onOpen(sub)}}><Text style={s.link}>Review subscriptions →</Text></Pressable></View>
    <View style={s.noAds}><MaterialCommunityIcons name="shield-check-outline" size={22} color="#111827"/><View style={{flex:1}}><Text style={s.noAdsTitle}>No ads. Ever.</Text><Text style={s.noAdsText}>Your personal documents shouldn't be surrounded by advertising.</Text></View></View>
  </ScrollView>
}
function Radar({items,onOpen}){
  const live=radarItems(items);
  const overdue=live.filter(x=>x.daysLive<0);
  const next=live.filter(x=>x.daysLive>=0&&x.daysLive<=30);
  return <ScrollView contentContainerStyle={s.content}>
    <Text style={s.h1}>Radar</Text><Text style={s.sub}>LIFEOS is watching the things you asked it to remember.</Text>
    {overdue.length>0&&<><Text style={s.section}>OVERDUE</Text>{overdue.map(x=>{const u=urgency(x.daysLive);return <Pressable key={x.id} onPress={()=>onOpen(x)} style={s.row}><View style={[s.iconBox,{borderColor:'#FFD4D8'}]}><MaterialCommunityIcons name={x.icon||'alert-outline'} size={22} color={u.color}/></View><View style={{flex:1}}><Text style={s.cardTitle}>{x.title}</Text><Text style={s.cardSub}>{x.deadlineLabel||'Deadline'} · {Math.abs(x.daysLive)} day{x.daysLive===-1?'':'s'} overdue</Text></View></Pressable>})}</>}
    <Text style={s.section}>NEXT 30 DAYS</Text>
    {next.length===0?<View style={s.emptyCard}><Text style={s.emptyTitle}>All clear.</Text><Text style={s.emptyText}>Nothing with a deadline in the next 30 days.</Text></View>:next.map(x=>{const u=urgency(x.daysLive);return <Pressable key={x.id} onPress={()=>onOpen(x)} style={s.row}><View style={s.iconBox}><MaterialCommunityIcons name={x.icon||'file-outline'} size={22} color={u.color}/></View><View style={{flex:1}}><Text style={s.cardTitle}>{x.title}</Text><Text style={s.cardSub}>{x.deadlineLabel||'Deadline'} · {u.label}</Text></View><MaterialCommunityIcons name="chevron-right" size={20} color="#A7ADB8"/></Pressable>})}
  </ScrollView>
}
function askLIFEOS(items, question){
  const q=(question||'').toLowerCase().trim();
  if(!q) return {title:'Ask anything', body:'Try asking about subscriptions, deadlines, warranties, purchases, or what needs attention.'};

  const subscriptions=items.filter(x=>/subscription/i.test(x.type||''));
  const deadlineItems=items.filter(x=>x.deadline);
  const warrantyItems=items.filter(x=>x.warranty);
  const totalSubscriptions=subscriptions.reduce((sum,x)=>sum+Number(x.amount||0),0);

  if(/subscription|recurring|monthly payment/.test(q)){
    if(!subscriptions.length) return {title:'Subscriptions',body:'I don’t have any tracked subscriptions yet.'};
    return {title:'Your subscriptions',body:`${subscriptions.length} tracked subscription${subscriptions.length===1?'':'s'}, totaling ${money(totalSubscriptions)} per month.\n\n${subscriptions.map(x=>`• ${x.title} — ${money(x.amount)}/month`).join('\n')}`};
  }
  if(/deadline|due|expir|renew/.test(q)){
    const live=radarItems(deadlineItems).slice(0,8);
    if(!live.length) return {title:'Deadlines',body:'I don’t have any tracked deadlines yet.'};
    return {title:'Your upcoming dates',body:live.map(x=>`• ${x.title} — ${x.deadlineLabel||'Deadline'}: ${daysText(x.daysLive)}`).join('\n')};
  }
  if(/warranty|warranties/.test(q)){
    if(!warrantyItems.length) return {title:'Warranties',body:'I don’t have any warranty information saved yet.'};
    return {title:'Your warranties',body:warrantyItems.map(x=>`• ${x.title} — warranty ${x.warranty}`).join('\n')};
  }
  if(/amazon|purchase|bought|buy|receipt|order/.test(q)){
    const purchases=items.filter(x=>/purchase/i.test(x.type||'') || /amazon|receipt|order/i.test(`${x.merchant||''} ${x.title||''}`));
    if(!purchases.length) return {title:'Purchases',body:'I don’t have a matching purchase saved yet.'};
    return {title:'Matching purchases',body:purchases.map(x=>`• ${x.title} — ${x.merchant||'Unknown merchant'} · ${money(x.amount)}`).join('\n')};
  }
  if(/today|this week|attention|important/.test(q)){
    const important=getTodayBriefingFallback(items);
    return {title:'What matters',body:important.length?important.map(x=>`• ${x.title} — ${x.deadlineLabel||'Deadline'} ${daysText(x.daysLive)}`).join('\n'):'Nothing urgent is currently tracked.'};
  }

  const terms=q.split(/\s+/).filter(x=>x.length>2);
  const matches=items.filter(x=>terms.some(t=>`${x.title||''} ${x.merchant||''} ${x.type||''} ${x.deadlineLabel||''}`.toLowerCase().includes(t))).slice(0,8);
  if(matches.length) return {title:'I found these',body:matches.map(x=>`• ${x.title} — ${x.merchant||x.type||'Saved item'}`).join('\n')};
  return {title:'I couldn’t find that yet',body:'Try a more specific question, or add the document, receipt, bill, or subscription to LIFEOS first.'};
}
function getTodayBriefingFallback(items){
  return radarItems(items).filter(x=>x.daysLive==null || x.daysLive<=7).slice(0,3);
}
function Ask({items}){
  const [q,setQ]=useState('');
  const [a,setA]=useState(null);
  const submit=()=>setA(aiAnswerPersonalMemory(items,q));
  const suggestions=['What subscriptions am I paying for?','What deadlines are coming up?','What warranties do I have?','What should I take care of this week?'];
  return <ScrollView contentContainerStyle={s.content}>
    <Text style={s.h1}>Ask LIFEOS</Text>
    <Text style={s.sub}>Ask about the things you have chosen to remember.</Text>
    <View style={s.askBox}><TextInput value={q} onChangeText={setQ} onSubmitEditing={submit} returnKeyType="search" placeholder="What do I need to know?" placeholderTextColor="#9AA1AD" style={s.input}/><Pressable onPress={submit} style={s.askButton}><MaterialCommunityIcons name="arrow-up" size={22} color="#fff"/></Pressable></View>
    {a?<View style={s.answer}><Text style={s.answerLabel}>LIFEOS</Text><Text style={s.answerTitle}>{a.title}</Text><Text style={s.answerText}>{a.body}</Text></View>:<View style={s.suggestions}>{suggestions.map(x=><Pressable key={x} onPress={()=>{setQ(x);setA(aiAnswerPersonalMemory(items,x))}} style={s.suggestion}><Text style={s.suggestionText}>{x}</Text><MaterialCommunityIcons name="arrow-top-right" size={17} color="#7A8290"/></Pressable>)}</View>}
  </ScrollView>
}

async function createPdfFromImage(uri, fileName='lifeos-document.jpg'){
  if(!uri) throw new Error('No image selected.');
  const safeUri=String(uri).replace(/"/g,'&quot;');
  const html=`<!doctype html><html><body style="margin:0;padding:0;"><img src="${safeUri}" style="width:100%;height:auto;display:block;"/></body></html>`;
  const result=await Print.printToFileAsync({html});
  if(!result?.uri) throw new Error('PDF generation failed.');
  return result.uri;
}

async function shareFile(uri){
  if(!uri) throw new Error('No file was created.');
  const available=await Sharing.isAvailableAsync();
  if(available) await Sharing.shareAsync(uri);
}

async function pickDocument({multiple=false,pdfOnly=false}={}){
  const result=await DocumentPicker.getDocumentAsync({
    type:pdfOnly?'application/pdf':['application/pdf','image/jpeg','image/png','image/webp','text/plain'],
    copyToCacheDirectory:true,
    multiple
  });
  if(result.canceled) return multiple?[]:null;
  return multiple?(result.assets||[]):(result.assets?.[0]||null);
}

async function runDocumentOperation(operation, asset){
  if(operation==='image-to-pdf'){
    if(!asset?.uri) throw new Error('Choose an image first.');
    const name=(asset.name||'').toLowerCase();
    const isImage=/\.(jpg|jpeg|png|webp)$/.test(name) || String(asset.mimeType||'').startsWith('image/');
    if(!isImage) throw new Error('Image → PDF needs a JPG, PNG or WebP image.');
    return createPdfFromImage(asset.uri,asset.name);
  }
  if(operation==='merge'){
    const assets=asset||[];
    if(assets.length<2) throw new Error('Choose at least two PDF files.');
    return mergePdfs(assets.map(x=>x.uri));
  }
  if(operation==='split'){
    if(!asset?.uri) throw new Error('Choose a PDF first.');
    return splitPdf(asset.uri,asset.pageNumbers);
  }
  if(operation==='compress'){
    if(!asset?.uri) throw new Error('Choose a PDF first.');
    return compressPdf(asset.uri);
  }
  throw new Error('Unknown document operation.');
}

function Tools({onCapture}){
  const [status,setStatus]=useState('');
  const [busy,setBusy]=useState(false);
  const [lastFile,setLastFile]=useState(null);
  const [splitAsset,setSplitAsset]=useState(null);
  const [splitPages,setSplitPages]=useState('1');
  const [billing,setBilling]=useState({entitlement:{isPro:false},usage:null});
  useEffect(()=>{Promise.all([getEntitlement(),getUsage()]).then(([entitlement,usage])=>setBilling({entitlement,usage})).catch(()=>{});},[]);

  const execute=async(operation)=>{
    try{
      const entitlement=await getEntitlement(); const usage=await getUsage();
      if(!canUse(entitlement,usage,'pdfOperations')){setStatus('Free PDF limit reached. Open Settings → LIFEOS Pro to continue.');return;}
      setBilling({entitlement,usage});
      setBusy(true);
      setStatus(operation==='merge'?'Choose PDFs…':`Choose a PDF to ${operation}…`);
      if(operation==='merge'){
        const assets=await pickDocument({multiple:true,pdfOnly:true});
        if(!assets.length){setStatus('Cancelled.');return;}
        setStatus(`Combining ${assets.length} PDFs locally…`);
        const uri=await runDocumentOperation('merge',assets);
        setLastFile(uri);setStatus('PDFs merged successfully.');if(!entitlement.isPro)setBilling({entitlement,usage:await consumeUsage('pdfOperations')});await shareFile(uri);return;
      }
      const asset=await pickDocument({pdfOnly:true});
      if(!asset){setStatus('Cancelled.');return;}
      if(operation==='split'){
        setSplitAsset(asset);setStatus('Enter the page numbers to extract, then tap Split PDF.');return;
      }
      setStatus('Optimizing PDF locally…');
      const uri=await runDocumentOperation('compress',asset);
      setLastFile(uri);setStatus('Optimized PDF created.');if(!entitlement.isPro)setBilling({entitlement,usage:await consumeUsage('pdfOperations')});await shareFile(uri);
    }catch(e){setStatus(e?.message||'PDF operation failed.');}
    finally{setBusy(false);}
  };

  const executeSplit=async()=>{
    if(!splitAsset)return;
    try{
      const entitlement=await getEntitlement(); const usage=await getUsage();
      if(!canUse(entitlement,usage,'pdfOperations')){setStatus('Free PDF limit reached. Open Settings → LIFEOS Pro to continue.');return;}
      setBusy(true);setStatus('Extracting selected pages locally…');
      const pages=splitPages.split(',').map(x=>Number(x.trim())).filter(Number.isInteger);
      const uri=await runDocumentOperation('split',{uri:splitAsset.uri,pageNumbers:pages});
      setLastFile(uri);setStatus('Split PDF created successfully.');if(!entitlement.isPro)setBilling({entitlement,usage:await consumeUsage('pdfOperations')});setSplitAsset(null);await shareFile(uri);
    }catch(e){setStatus(e?.message||'Could not split PDF.');}
    finally{setBusy(false);}
  };

  const makeImagePdf=async()=>{
    try{
      setBusy(true);setStatus('Choose an image…');
      const asset=await pickDocument();
      if(!asset){setStatus('Cancelled.');return;}
      const entitlement=await getEntitlement(); const usage=await getUsage();
      if(!canUse(entitlement,usage,'pdfOperations')){setStatus('Free PDF limit reached. Open Settings → LIFEOS Pro to continue.');return;}
      setStatus('Creating PDF locally…');
      const uri=await runDocumentOperation('image-to-pdf',asset);
      setLastFile(uri);setStatus('PDF created successfully.');if(!entitlement.isPro)setBilling({entitlement,usage:await consumeUsage('pdfOperations')});await shareFile(uri);
    }catch(e){setStatus(e?.message||'PDF operation failed.');}
    finally{setBusy(false);}
  };

  return <ScrollView contentContainerStyle={s.content}>
    <Text style={s.h1}>Tools</Text>
    <Text style={s.sub}>Local document utilities. PDF operations run on-device.</Text>
    <Pressable disabled={busy} style={s.toolHero} onPress={makeImagePdf}>
      <MaterialCommunityIcons name="file-pdf-box" size={32} color="#fff"/><View style={{flex:1}}><Text style={s.toolHeroTitle}>Image → PDF</Text><Text style={s.toolHeroSub}>Create a PDF from a JPG, PNG or WebP.</Text></View><MaterialCommunityIcons name="chevron-right" size={26} color="#fff"/>
    </Pressable>
    <View style={s.grid}>
      <Pressable disabled={busy} style={s.tool} onPress={()=>execute('merge')}><MaterialCommunityIcons name="file-merge-outline" size={26} color="#111827"/><Text style={s.toolTitle}>Merge PDF</Text><Text style={s.toolDesc}>Combine multiple PDFs.</Text></Pressable>
      <Pressable disabled={busy} style={s.tool} onPress={()=>execute('split')}><MaterialCommunityIcons name="content-cut" size={26} color="#111827"/><Text style={s.toolTitle}>Split PDF</Text><Text style={s.toolDesc}>Extract selected pages.</Text></Pressable>
      <Pressable disabled={busy} style={s.tool} onPress={()=>execute('compress')}><MaterialCommunityIcons name="compress" size={26} color="#111827"/><Text style={s.toolTitle}>Optimize PDF</Text><Text style={s.toolDesc}>Re-save with PDF object streams.</Text></Pressable>
      <Pressable style={s.tool} onPress={()=>onCapture('camera')}><MaterialCommunityIcons name="text-box-outline" size={26} color="#111827"/><Text style={s.toolTitle}>OCR Scanner</Text><Text style={s.toolDesc}>Scan and extract text.</Text></Pressable>
    </View>
    {splitAsset?<View style={s.toolStatus}><Text style={s.toolStatusTitle}>Split pages</Text><Text style={s.toolStatusText}>Enter pages like 1,3,5. LIFEOS will validate them against the selected PDF.</Text><TextInput value={splitPages} onChangeText={setSplitPages} keyboardType="numbers-and-punctuation" placeholder="1,2" style={s.input}/><Pressable disabled={busy} style={s.bigAction} onPress={executeSplit}><Text style={s.bigActionText}>Split PDF</Text></Pressable></View>:null}
    {status?<View style={s.toolStatus}><Text style={s.toolStatusTitle}>{busy?'Working…':'Document status'}</Text><Text style={s.toolStatusText}>{status}</Text>{lastFile?<Text style={s.toolStatusText}>Created file: {lastFile}</Text>:null}</View>:null}
  </ScrollView>
}
function Memory({items,query,setQuery,onOpen}){
  const q=(query||'').toLowerCase().trim();
  const filtered=q?items.filter(x=>`${x.title||''} ${x.merchant||''} ${x.type||''} ${x.deadlineLabel||''} ${x.warranty||''}`.toLowerCase().includes(q)):items;
  return <View style={{flex:1}}>
    <View style={s.search}><MaterialCommunityIcons name="magnify" size={21} color="#8B93A0"/><TextInput value={query} onChangeText={setQuery} placeholder="Search your LIFEOS" placeholderTextColor="#9AA1AD" style={{flex:1,fontSize:16}}/></View>
    <Text style={s.resultCount}>{filtered.length} saved item{filtered.length===1?'':'s'}</Text>
    <FlatList data={filtered} keyExtractor={x=>x.id} contentContainerStyle={s.list} ListEmptyComponent={<View style={s.emptyCard}><Text style={s.emptyTitle}>Nothing found.</Text><Text style={s.emptyText}>Try a merchant, product, document type or keyword.</Text></View>} renderItem={({item})=><Pressable onPress={()=>onOpen(item)} style={s.row}><View style={s.iconBox}><MaterialCommunityIcons name={item.icon||'file-outline'} size={22} color="#111827"/></View><View style={{flex:1}}><Text style={s.cardTitle}>{item.title}</Text><Text style={s.cardSub}>{item.merchant||'Saved item'} · {item.type||'Document'}</Text></View><Text style={s.smallAmount}>{money(item.amount)}</Text></Pressable>}/>
  </View>
}
function Paste({close,value,setValue,submit}){return <Center><KeyboardAvoidingView behavior="padding" style={{width:'100%'}}><View style={s.sheet}><View style={s.handle}/><Text style={s.h2}>Paste document text</Text><Text style={s.sub}>Paste text from a receipt, email, bill or booking. LIFEOS will extract useful facts without a paid AI service.</Text><TextInput multiline value={value} onChangeText={setValue} placeholder={'Example:\nAmazon\nAirPods Pro\n$249.00\nReturn by October 17, 2026\nWarranty until September 17, 2027'} placeholderTextColor="#9AA1AD" style={s.pasteInput}/><Pressable style={s.bigAction} onPress={submit}><MaterialCommunityIcons name="brain" size={22} color="#fff"/><Text style={s.bigActionText}>Understand & save</Text></Pressable><Pressable onPress={close} style={s.cancel}><Text>Cancel</Text></Pressable></View></KeyboardAvoidingView></Center>}

function Capture({close,on,onDemo}){return <Center><View style={s.sheet}><View style={s.handle}/><Text style={s.h2}>Add to LIFEOS</Text><Text style={s.sub}>Give LIFEOS anything you want it to remember.</Text><Pressable style={s.bigAction} onPress={()=>on('camera')}><MaterialCommunityIcons name="camera-outline" size={27} color="#fff"/><Text style={s.bigActionText}>Scan with camera</Text></Pressable><Pressable style={s.option} onPress={()=>on('photo')}><MaterialCommunityIcons name="image-outline" size={23} color="#111827"/><Text style={s.optionText}>Choose photo or screenshot</Text></Pressable><Pressable style={s.option} onPress={()=>on('file')}><MaterialCommunityIcons name="file-document-outline" size={23} color="#111827"/><Text style={s.optionText}>Choose PDF or document</Text></Pressable><Pressable style={s.option} onPress={()=>on('paste')}><MaterialCommunityIcons name="text-box-outline" size={23} color="#111827"/><Text style={s.optionText}>Paste text to understand</Text></Pressable><Pressable style={s.demo} onPress={()=>onDemo()}><Text style={s.demoText}>Try the demo receipt</Text></Pressable><Pressable onPress={close} style={s.cancel}><Text>Cancel</Text></Pressable></View></Center>}
function Result({close,save,pending}){const demo=pending?.source==='demo';const x=pending?.extracted;const extracted=demo?{title:'AirPods Pro',merchant:'Amazon',amount:249,deadline:'Oct 17, 2026',deadlineLabel:'Return deadline',days:daysUntil('Oct 17, 2026'),warranty:'Sep 17, 2027'}:x;return <Center><View style={s.sheet}><View style={s.handle}/><Text style={s.eyebrow}>{demo||x?'LIFEOS FOUND':'CAPTURED'}</Text><Text style={s.h2}>{extracted?.title||pending?.name||'Imported document'}</Text><Text style={s.sub}>{extracted?`${extracted.merchant||'Imported'} · ${extracted.type||'Document'}`:'Ready for LIFEOS review'}</Text><View style={s.extracted}>{extracted?<><KV k="Amount" v={extracted.amount?money(extracted.amount):'Not detected'}/><KV k={extracted.deadlineLabel||'Deadline'} v={extracted.deadline||'Not detected'}/>{extracted.warranty&&<KV k="Warranty" v={extracted.warranty}/>}<KV k="Source" v={pending?.source||'text'}/><KV k="Extraction" v={demo?'Demo':'On-device OCR + parser'}/></>:<><KV k="Source" v={pending?.source||'document'}/><KV k="Status" v={pending?.ocrError?'Needs text input':'Captured'}/><KV k="Next" v={pending?.ocrError||'No extractable text found yet'}/></>}</View>{extracted?.deadline&&extracted.days<900&&<Text style={s.monitor}>✓ Deadline will be monitored</Text>}{extracted?.warranty&&<Text style={s.monitor}>✓ Warranty information saved</Text>}<Pressable style={s.bigAction} onPress={save}><Text style={s.bigActionText}>{extracted?'Save & start monitoring':'Save to LIFEOS'}</Text></Pressable><Pressable onPress={close} style={s.cancel}><Text>Cancel</Text></Pressable></View></Center>}
function KV({k,v}){return <View style={s.kv}><Text style={s.k}>{k}</Text><Text style={s.v}>{v}</Text></View>}
function ItemDetail({item,close}){return <Center><View style={s.sheet}><View style={s.handle}/><View style={s.detailIcon}><MaterialCommunityIcons name={item.icon||'file-outline'} size={30} color="#111827"/></View><Text style={s.h2}>{item.title}</Text><Text style={s.sub}>{item.merchant} · {money(item.amount)}</Text><View style={s.extracted}><KV k={item.deadlineLabel} v={item.deadline}/><KV k="Status" v="Monitoring"/><KV k="Type" v={item.type}/></View><Pressable style={s.option}><MaterialCommunityIcons name="bell-outline" size={22} color="#111827"/><Text style={s.optionText}>Monitoring enabled</Text></Pressable><Pressable onPress={close} style={s.cancel}><Text>Done</Text></Pressable></View></Center>}
function Settings({close,openMonitoring,openPro}){return <Center><View style={s.sheet}><View style={s.handle}/><Text style={s.h2}>Settings</Text><Pressable style={s.option}><MaterialCommunityIcons name="shield-check-outline" size={22} color="#111827"/><Text style={s.optionText}>Privacy & security</Text></Pressable><Pressable onPress={openPro} style={s.option}><MaterialCommunityIcons name="credit-card-outline" size={22} color="#111827"/><Text style={s.optionText}>LIFEOS Pro</Text></Pressable><Pressable onPress={openMonitoring} style={s.option}><MaterialCommunityIcons name="bell-outline" size={22} color="#111827"/><Text style={s.optionText}>Notifications & monitoring</Text></Pressable><Pressable onPress={close} style={s.cancel}><Text>Done</Text></Pressable></View></Center>}
function Center({children}){return <View style={s.overlay}>{children}</View>}

const s=StyleSheet.create({toolStatus:{marginTop:18,padding:16,borderRadius:18,backgroundColor:'#EEF1F6'},toolStatusTitle:{fontSize:15,fontWeight:'800',color:'#111827'},toolStatusText:{fontSize:13,color:'#667085',marginTop:5,lineHeight:19},answerTitle:{fontSize:18,fontWeight:'800',color:'#111827',marginBottom:8},resultCount:{fontSize:12,color:'#8A929F',paddingHorizontal:22,paddingBottom:4},emptyCard:{backgroundColor:'#fff',borderRadius:18,padding:18,marginBottom:12,borderWidth:1,borderColor:'#ECEEF2'},emptyTitle:{fontSize:16,fontWeight:'800',color:'#111827'},emptyText:{fontSize:13,color:'#7C8491',marginTop:5},safe:{flex:1,backgroundColor:'#F7F8FA'},top:{paddingHorizontal:22,paddingTop:12,paddingBottom:8,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},logo:{fontSize:22,fontWeight:'900',letterSpacing:2,color:'#111827'},tag:{fontSize:11,color:'#8B93A0',marginTop:2},avatar:{width:36,height:36,borderRadius:18,backgroundColor:'#E7E9EE',alignItems:'center',justifyContent:'center'},avatarText:{fontWeight:'800',color:'#111827'},content:{padding:22,paddingBottom:110},greeting:{marginTop:12,marginBottom:20},h1:{fontSize:31,fontWeight:'800',color:'#111827',letterSpacing:-.8},h2:{fontSize:25,fontWeight:'800',color:'#111827',marginBottom:5},sub:{fontSize:14,color:'#727B89',lineHeight:21},captureHero:{backgroundColor:'#111827',borderRadius:22,padding:18,flexDirection:'row',alignItems:'center',marginBottom:28},captureIcon:{width:48,height:48,borderRadius:16,backgroundColor:'#2D3440',alignItems:'center',justifyContent:'center',marginRight:14},captureTitle:{fontSize:17,fontWeight:'800',color:'#fff'},captureSub:{fontSize:12,color:'#B8BEC8',marginTop:3},section:{fontSize:11,fontWeight:'800',letterSpacing:1.4,color:'#8A929F',marginBottom:10,marginTop:6},alertCard:{backgroundColor:'#fff',borderRadius:18,padding:16,marginBottom:9,flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:'#ECEEF2'},dot:{width:9,height:9,borderRadius:5,marginRight:13},cardTitle:{fontSize:12,fontWeight:'700',color:'#7C8491'},cardMain:{fontSize:16,fontWeight:'800',color:'#171B22',marginTop:2},cardSub:{fontSize:12,color:'#8B93A0',marginTop:3},when:{fontSize:12,fontWeight:'800',color:'#111827'},moneyCard:{backgroundColor:'#fff',borderRadius:20,padding:18,borderWidth:1,borderColor:'#ECEEF2',marginBottom:18},moneyRow:{flexDirection:'row',alignItems:'baseline',gap:7},moneyBig:{fontSize:30,fontWeight:'900',color:'#111827'},moneyLabel:{fontSize:13,color:'#727B89'},moneyHint:{fontSize:13,color:'#727B89',marginTop:4},link:{fontSize:13,fontWeight:'800',color:'#111827',marginTop:13},noAds:{backgroundColor:'#EEF0F3',borderRadius:18,padding:15,flexDirection:'row',gap:12,alignItems:'center'},noAdsTitle:{fontWeight:'800',color:'#111827'},noAdsText:{fontSize:12,color:'#6E7785',marginTop:2,lineHeight:17},nav:{position:'absolute',bottom:0,left:0,right:0,height:78,backgroundColor:'rgba(255,255,255,.98)',borderTopWidth:1,borderTopColor:'#E8EAEF',flexDirection:'row',justifyContent:'space-around',paddingTop:9},navItem:{alignItems:'center',width:70},navText:{fontSize:10,color:'#9AA1AD',marginTop:3,fontWeight:'600'},navActive:{color:'#111827',fontWeight:'800'},row:{backgroundColor:'#fff',borderRadius:17,padding:14,marginBottom:9,flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:'#ECEEF2'},iconBox:{width:44,height:44,borderRadius:14,backgroundColor:'#F0F1F4',alignItems:'center',justifyContent:'center',marginRight:13},smallAmount:{fontSize:13,fontWeight:'800',color:'#111827'},search:{margin:12,marginTop:8,backgroundColor:'#fff',borderRadius:16,paddingHorizontal:14,height:50,flexDirection:'row',alignItems:'center',gap:8,borderWidth:1,borderColor:'#E8EAF0'},list:{padding:10,paddingBottom:100},askBox:{marginTop:22,backgroundColor:'#fff',borderRadius:19,padding:9,paddingLeft:15,flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:'#E5E7EB'},input:{flex:1,fontSize:15,color:'#111827',minHeight:42},askButton:{width:40,height:40,borderRadius:14,backgroundColor:'#111827',alignItems:'center',justifyContent:'center'},suggestions:{marginTop:18},suggestion:{backgroundColor:'#fff',padding:16,borderRadius:15,marginBottom:8,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderWidth:1,borderColor:'#ECEEF2'},suggestionText:{fontSize:14,color:'#343B46'},answer:{marginTop:18,backgroundColor:'#fff',borderRadius:18,padding:18,borderWidth:1,borderColor:'#ECEEF2'},answerLabel:{fontSize:10,fontWeight:'900',letterSpacing:1.2,color:'#8B93A0',marginBottom:8},answerText:{fontSize:16,lineHeight:25,color:'#20252D'},pasteInput:{marginTop:18,minHeight:180,maxHeight:260,backgroundColor:'#fff',borderWidth:1,borderColor:'#E5E7EB',borderRadius:16,padding:15,textAlignVertical:'top',fontSize:14,color:'#111827'},toolHero:{backgroundColor:'#111827',borderRadius:21,padding:18,flexDirection:'row',alignItems:'center',gap:14,marginTop:22,marginBottom:13},toolHeroTitle:{color:'#fff',fontSize:18,fontWeight:'800'},toolHeroSub:{color:'#B8BEC8',fontSize:12,lineHeight:18,marginTop:4},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},tool:{width:'48.3%',backgroundColor:'#fff',borderRadius:18,padding:16,marginBottom:10,borderWidth:1,borderColor:'#ECEEF2',minHeight:145},toolTitle:{fontSize:14,fontWeight:'800',color:'#111827',marginTop:14},toolDesc:{fontSize:11,color:'#7D8592',lineHeight:16,marginTop:4},overlay:{flex:1,backgroundColor:'rgba(17,24,39,.35)',justifyContent:'flex-end'},sheet:{backgroundColor:'#F9FAFB',borderTopLeftRadius:28,borderTopRightRadius:28,padding:22,paddingBottom:30},handle:{width:42,height:4,borderRadius:3,backgroundColor:'#D1D5DB',alignSelf:'center',marginBottom:20},bigAction:{height:56,borderRadius:17,backgroundColor:'#111827',alignItems:'center',justifyContent:'center',flexDirection:'row',gap:10,marginTop:18},bigActionText:{color:'#fff',fontWeight:'800',fontSize:15},option:{backgroundColor:'#fff',borderRadius:16,padding:16,marginTop:9,flexDirection:'row',alignItems:'center',gap:12,borderWidth:1,borderColor:'#E7E9EE'},optionText:{fontSize:14,fontWeight:'700',color:'#20252D'},demo:{alignItems:'center',padding:15},demoText:{fontWeight:'800',color:'#111827'},cancel:{alignItems:'center',padding:15},processing:{backgroundColor:'#fff',borderRadius:25,padding:30,alignItems:'center',margin:22},processTitle:{fontSize:19,fontWeight:'800',marginTop:14,color:'#111827'},muted:{fontSize:13,color:'#7D8592',marginTop:5},eyebrow:{fontSize:10,fontWeight:'900',letterSpacing:1.4,color:'#8B93A0',marginBottom:8},extracted:{backgroundColor:'#fff',borderRadius:18,padding:4,marginTop:18,borderWidth:1,borderColor:'#E7E9EE'},kv:{padding:13,flexDirection:'row',justifyContent:'space-between',borderBottomWidth:1,borderBottomColor:'#F0F1F4'},k:{fontSize:13,color:'#7A8290'},v:{fontSize:13,fontWeight:'800',color:'#111827'},monitor:{fontSize:13,fontWeight:'700',color:'#2D6A4F',marginTop:9},detailIcon:{width:58,height:58,borderRadius:18,backgroundColor:'#ECEEF2',alignItems:'center',justifyContent:'center',marginBottom:12}});

export { AccountScreen };
